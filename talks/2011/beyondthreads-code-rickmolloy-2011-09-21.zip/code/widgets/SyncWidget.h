#pragma once
#include "common.h"
#include "AtomicWidget.h"

class SyncWidget
{
public:
    typedef AtomicWidget::DimType  DimType;
    typedef AtomicWidget::RectType RectType;
    SyncWidget(){}

    void Resize(DimType x, DimType y) {
        lock_guard<Lock> guard(m_lock);
        m_widget.Resize(x,y);
    }

    RectType GetDims(){
        lock_guard<Lock> guard(m_lock);
        return m_widget.GetDims();
    }
private:
    typedef mutex     Lock;
    AtomicWidget m_widget;
    Lock         m_lock;
};
