#pragma once
#include "common.h"
#include "AtomicWidget.h"

class AsyncWidget
{
public:
    typedef AtomicWidget::DimType  DimType;
    typedef AtomicWidget::RectType RectType;

    AsyncWidget(){
        m_resizeBuffer.reset(new Resizer([this](RectType rect) -> RectType {
            m_widget.Resize(rect.first, rect.second);
            return rect;
        }));
        connect(m_resizeBuffer, m_output);
    }

    void Resize(DimType x, DimType y) {
        send(m_resizeBuffer.get(), make_pair(x,y));
    }

    RectType GetDims(){
        return m_output.value();
    }
private:
    typedef transformer<RectType, RectType> Resizer;
    unique_ptr<Resizer>        m_resizeBuffer;
    overwrite_buffer<RectType> m_output;
    AtomicWidget               m_widget;
};