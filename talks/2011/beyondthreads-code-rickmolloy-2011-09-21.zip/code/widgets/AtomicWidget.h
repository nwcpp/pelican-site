#pragma once
#include "common.h"

class AtomicWidget
{
public:
    typedef unsigned long               DimType;
    typedef std::pair<DimType,DimType>  RectType;

    AtomicWidget(){}

    void Resize(DimType x, DimType y) {
        m_dims.first  = x;
        m_dims.second = y;
    }

    RectType GetDims(){
        return m_dims;
    }

private:
    RectType m_dims;
};