#pragma once

template <class TStateTable, class StateType, class EventType>
class StateMachine
{
public:
    StateMachine(TStateTable && stateTable, StateType state) : m_stateTable(std::forward<TStateTable>(stateTable)),
        m_state(state)
    {}
    void Process(EventType event)
    {
        auto & transition = m_stateTable.GetEntry(m_state, event);
        if(transition.IsValid())
        {
            transition();
            m_state = transition.GetState();
        }
    }
private:
    TStateTable                 m_stateTable;
    StateType                   m_state;
};


template <typename EventType, typename TStateTable, typename StateType>
StateMachine<TStateTable, StateType, EventType> MakeStateMachine(TStateTable && table, StateType init)
{
  return StateMachine<TStateTable, StateType, EventType>(std::forward<TStateTable>(table), init);
}
