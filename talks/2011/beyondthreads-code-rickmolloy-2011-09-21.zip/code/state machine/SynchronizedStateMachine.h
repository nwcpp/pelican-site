#pragma once
#include "StateMachine.h"

#include <ppl.h>

//note this class will deadlock
template <class TStateTable, class StateType, class EventType>
class SynchronizedStateMachine
{
public:
    typedef StateMachine<TStateTable, StateType, EventType> StateMachine;

    SynchronizedStateMachine(TStateTable && stateTable, StateType state) :
                m_stateMachine(std::forward<TStateTable>(stateTable), state)
    {
    }
    inline void Process(EventType event)
    {
        std::lock_guard<mutex> lock(m_lock);
        m_stateMachine.Process(std::move(event));
    }
private:
    std::mutex                                      m_lock;
    StateMachine                                    m_stateMachine;
};

template <typename EventType, typename TStateTable, typename StateType>
SynchronizedStateMachine<TStateTable, StateType, EventType> MakeAsyncStateMachine(TStateTable && table, StateType init)
{
    return SynchronizedStateMachine<TStateTable, StateType, EventType>(std::forward<TStateTable>(table), init);
}