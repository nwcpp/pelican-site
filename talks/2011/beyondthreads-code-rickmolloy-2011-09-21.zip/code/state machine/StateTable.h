#pragma once

#include "make_unique.h"
#include "Transition.h"

#include <functional>
#include <unordered_map>
#include <algorithm>
#include <assert.h>
#include <agents.h>

template <typename StateType, 
          typename EventType>
class StateTable
{
public:
    typedef StateType                       StateType;
    typedef EventType                       EventType;
    typedef detail::EventHandler            EventHandler;
    typedef detail::Transition<StateType>   Transition;
    StateTable()
    {
    }
    bool AddEntry(StateType old, StateType newState, EventType event, EventHandler fn)
    {
        bool result = false;
        //if the state transition doesn't exist, insert it.
        auto & transition = m_stateTransitions[old][event];
        if(!transition.IsValid())
        {
            transition = Transition(std::forward<StateType>(newState));
        }
        if(transition.GetState() == newState)
        {
            transition.Add(fn);
            result = true;
        }
        return result;
    }

    Transition & GetEntry(StateType old, EventType event)
    {
        Transition& result  = m_invalidTransition;
        auto& transitionMap = m_stateTransitions.find(old);
        if(transitionMap   != m_stateTransitions.end())
        {
            auto transition = transitionMap->second.find(event);
            if(transition  != transitionMap->second.end())
            {
                result = transition->second;
            }
        }
        return result;
    }
private:
    typedef std::unordered_map<EventType, Transition>    TransitionMap;
    typedef std::unordered_map<StateType, TransitionMap> StateMap;
    StateMap                m_stateTransitions;
    Transition              m_invalidTransition;
};