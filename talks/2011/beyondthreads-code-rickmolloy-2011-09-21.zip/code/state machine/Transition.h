#pragma once

#include <functional>
#include <vector>

namespace detail
{
    typedef std::function<void(void)> EventHandler;

    template <typename StateType>
    class Transition
    {
    public:
        Transition() : m_isValid(false) {}
        Transition(StateType const & state) : m_state(state), m_isValid(true){}
        void Add(EventHandler fn)
        {
            m_handlers.push_back(fn);
        }
        template <typename Func>
        void Add(Func && fn)
        {
            m_handlers.push_back(std::forward<Func>(fn));
        }
        void operator()()
        {
            std::for_each(m_handlers.begin(), m_handlers.end(),[](EventHandler & handler){ handler(); });
        }

        StateType GetState()    { return m_state;           }
        bool      IsValid()     { return m_isValid;         }
    private:
        std::vector<EventHandler> m_handlers;
        StateType                 m_state;
        bool                      m_isValid;
    };
}