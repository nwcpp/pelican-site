#include "StateTable.h"
#include "AsyncStateMachine.h"
#include "StateMachine.h"

#include <iostream>
#include <assert.h>
#include <functional>
#include <Windows.h>

using namespace ::std;

void Thunk()
{
    cout << "Thunk!" << endl;
}

void LightOff()
{
    cout << "light is off!" << endl;
}

void LightOn()
{
    cout << "light is on!" << endl;
}

enum LightStates  { on, off };
enum SwitchEvents { flick };

int main()
{

    StateTable<LightStates, SwitchEvents> states;

    states.AddEntry(on,  off, flick, Thunk);
    states.AddEntry(on,  off, flick, LightOff);
    states.AddEntry(off, on,  flick, LightOn);

    auto lightSwitch = MakeStateMachine<SwitchEvents>(states, off);

    //asynchronous version
    //auto lightSwitch = MakeAsyncStateMachine<SwitchEvents>(states, off);

    lightSwitch.Process(flick);
    lightSwitch.Process(flick);
    
    Concurrency::wait(1000);
}