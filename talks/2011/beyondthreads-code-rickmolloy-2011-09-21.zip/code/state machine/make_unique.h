#pragma once

#include <memory>

//make_unique helper functions
template <typename Type>
std::unique_ptr<Type> make_unique()
{
    return std::unique_ptr<Type>(new Type())
}

template <typename Type, typename Arg1>
std::unique_ptr<Type> make_unique(Arg1 && arg)
{
    return std::unique_ptr<Type>(new Type(std::forward<Arg1>(arg)));
}

template <typename Type, typename Arg1, typename Arg2>
std::unique_ptr<Type> make_unique(Arg1 && arg, Arg2 && arg2)
{
    return std::unique_ptr<Type>(new Type(std::forward<Arg1>(arg),
        std::forward<Arg2>(arg2)));
}

template <typename Type, typename Arg1, typename Arg2, typename Arg3>
std::unique_ptr<Type> make_unique(Arg1 && arg, Arg2 && arg2, Arg3 && arg3)
{
    return std::unique_ptr<Type>(new Type(std::forward<Arg1>(arg),
        std::forward<Arg2>(arg2),
        std::forward<Arg3>(arg3)));
}

template <typename Type, typename Arg1, typename Arg2, typename Arg3, typename Arg4>
std::unique_ptr<Type> make_unique(Arg1 && arg, Arg2 && arg2, Arg3 && arg3, Arg4 && arg4)
{
    return std::unique_ptr<Type>(new Type(std::forward<Arg1>(arg),
        std::forward<Arg2>(arg2),
        std::forward<Arg3>(arg3),
        std::forward<Arg4>(arg4)));
}