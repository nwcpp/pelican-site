#pragma once

#include "StateMachine.h"
#include <agents.h>
#include "make_unique.h"

//global usings, for demo purposes
using namespace ::Concurrency;
using namespace ::std;

template <class TStateTable, class StateType, class EventType>
class AsyncStateMachine
{
public:
    typedef StateMachine<TStateTable, StateType, EventType> StateMachine;

    AsyncStateMachine(TStateTable && stateTable, StateType state) :
                m_stateMachine(std::forward<TStateTable>(stateTable), state)
    {
        m_eventTask = make_unique<EventProcessor>([this](EventType event){m_stateMachine.Process(event);});
        //connect(m_inputEvents, m_eventTask);
        m_inputEvents.link_target(m_eventTask.get());
    }
    void Process(EventType event)
    {
        asend(m_inputEvents, event);
    }
private:
    typedef unbounded_buffer<EventType>             EventQueue;
    typedef call<EventType>                         EventProcessor;
    typedef unique_ptr<EventProcessor>              EventProcessorPtr;

    StateMachine                                     m_stateMachine;
    EventQueue                                       m_inputEvents;
    EventProcessorPtr                                m_eventTask;
};

template <typename EventType, typename TStateTable, typename StateType>
AsyncStateMachine<TStateTable, StateType, EventType> MakeAsyncStateMachine(TStateTable && table, StateType init)
{
    return AsyncStateMachine<TStateTable, StateType, EventType>(std::forward<TStateTable>(table), init);
}