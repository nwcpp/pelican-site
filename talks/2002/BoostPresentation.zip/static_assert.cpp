//////////////////////////////////////////////////////////////////////////////
//
//  static_assert.cpp
//      Example using boost's (www.boost.org) static_assert library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.9.2002 12:37 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <boost/static_assert.hpp>

//////////////////////////////////////////////////////////////////////////////
#if defined TEST_FUNCTION
    //////////////////////////////////////////////////////////////////////////////
    void Function(void)
    {
        BOOST_STATIC_ASSERT(sizeof(char) == 1);
        BOOST_STATIC_ASSERT(sizeof(int) == 1);
    }

#elif defined TEST_CLASS
    //////////////////////////////////////////////////////////////////////////////
    class MyClass
    {
        BOOST_STATIC_ASSERT(sizeof(char) == 1);
        BOOST_STATIC_ASSERT(sizeof(int) == 1);
    };

#elif defined TEST_NAMESPACE
    //////////////////////////////////////////////////////////////////////////////
    namespace Foo
    {
        BOOST_STATIC_ASSERT(sizeof(char) == 1);
        BOOST_STATIC_ASSERT(sizeof(int) == 1);
    }

#else
    //////////////////////////////////////////////////////////////////////////////
    #pragma message("*****  No test was defined, everything will compile as expected")
#endif

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    return(0);
}