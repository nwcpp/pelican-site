//////////////////////////////////////////////////////////////////////////////
//
//  function.cpp
//      Examples using boost's (www.boost.org) function library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.9.2002 1:22 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <boost/function.hpp>

#include "../MyObject.h"

//////////////////////////////////////////////////////////////////////////////
int MyAddFunction(int a, int b) { return(a + b); }
int MyMultFunction(int a, int b) { return(a * b); }

void function_example(void)
{
    boost::function2<int, int, int>     func;

    func = MyAddFunction;
    std::cout << "Add: " << func(3, 2) << "\n";

    func = MyMultFunction;
    std::cout << "Mult: " << func(3, 2) << "\n";

    if(func)
        std::cout << "Func is not empty\n";

    func.clear();
    if(!func)
        std::cout << "Func is empty\n";
}

//////////////////////////////////////////////////////////////////////////////
struct MyFunctionObject
{
    bool operator()(int i) { std::cout << "operator (): " << i << "\n"; return(true); }
};

void function_operator_example(void)
{
    MyFunctionObject                fo;
    boost::function1<bool, int>     func;

    func = fo;
    func(3);
    func(4);
}

//////////////////////////////////////////////////////////////////////////////
void member_function_example(void)
{
    MyObject                            obj("obj");
    boost::function1<void, MyObject *>  func;

    func = MyObject::Foo;
    
    if(func)
        func(&obj);

    func = MyObject::Bar;
    func(&obj);
}

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    std::cout << "\nfunction_example:\n";
    function_example();

    std::cout << "\nfunction_operator_example:\n";
    function_operator_example();

    std::cout << "\nmember_function_example:\n";
    member_function_example();

    return(0);
}