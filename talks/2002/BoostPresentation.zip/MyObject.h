//////////////////////////////////////////////////////////////////////////////
//
//  MyObject.h
//      A basic object that is used in the examples
//
//  Author:
//      David Brownell
//
//  Created:
//      11.9.2002 12:33 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <iostream>
#include <string>

//////////////////////////////////////////////////////////////////////////////
class MyObject
{
public:
    MyObject(const char *pszString = "Default") : str_(pszString) { std::cout << str_ << ": Constructor\n"; }
    MyObject(const MyObject &obj) : str_(obj.str_) { std::cout << str_ << ": Copy Constructor\n"; }
    ~MyObject(void) { std::cout << str_ << ": Destructor\n"; }

    void Foo(void) const { std::cout << str_ << ": Foo\n"; }
    void Bar(void) const { std::cout << str_ << ": Bar\n"; }

    void SetString(const char *pszString) { str_ = pszString; }

private:
    std::string         str_;
};