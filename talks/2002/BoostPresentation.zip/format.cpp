//////////////////////////////////////////////////////////////////////////////
//
//  format.cpp
//      Examples using boost's (www.boost.org) format library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.9.2002 2:31 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <boost/format.hpp>

#include "../MyObject.h"

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    //printf-style arguments
    std::cout << boost::format("%s %s (for the %dth time)\n") % "Hello" % "World!" % 103999;
    std::cout << boost::format("%s 0x%08X\n") % "A Hex value: " % 10;

    //Reordering style
    std::cout << boost::format("%1% %2% %3% %2% %1%\n") % "a" % "b" % "c";

    //Centering
    std::cout << boost::format("-%|=20|-\n") % "test";
    std::cout << boost::format("-%|=20|-\n") % "Another test";

    //Maintaining format object between uses
    boost::format           fmt("%1%, %2% %3%\n");

    std::cout << fmt % "Name" % "Phone" % "City";
    std::cout << fmt % "Alice" % 12345 % "Seattle, WA";
    std::cout << fmt % "Bob" % "555-1212" % "Bellevue";

    fmt % "Carol";
    
    //Printing here would throw a too_few_args exception, as only one argument has been placed
    fmt % "1 (206) 456-7890" % "Renton";

    std::cout << fmt;

    //Convert to a string
    std::string         str;

    str = boost::io::str(fmt);

    std::cout << str;
    
    //Too few arguments
    try
    {
        std::cout << boost::format("%s %s\n") % "One";
    }
    catch(boost::io::too_few_args &)
    {
        std::cout << "Expected exception\n";
    }

    //Too many arguments
    try
    {
        std::cout << boost::format("%s %s\n") % "One" % "Two" % "Three";
    }
    catch(boost::io::too_many_args &)
    {
        std::cout << "Expected exception\n";
    }

    return(0);
}