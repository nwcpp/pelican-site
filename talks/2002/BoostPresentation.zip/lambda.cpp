//////////////////////////////////////////////////////////////////////////////
//
//  lambda.cpp
//      Examples using boost's (www.boost.org) lambda library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.10.2002 9:20 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <boost/lambda/lambda.hpp>
#include <boost/lambda/bind.hpp>
#include <boost/lambda/construct.hpp>
#include <boost/lambda/control_structures.hpp>

#include <iostream>
#include <vector>
#include <algorithm>

using namespace boost::lambda;

//////////////////////////////////////////////////////////////////////////////
struct Object
{
    void Display(void) const { std::cout << "Object: " << i_ << "\n"; }

    int i_;
};

//////////////////////////////////////////////////////////////////////////////
void DisplayInt(int i)
{
    std::cout << "Int: " << i << "\n";
}

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    {
        int         a = 1;
        int         b = 2;

        //Free function lambda examples
        std::cout << (_1 + _2)(a, b) << "\n";
        std::cout << (_1 + _1)(a, b) << "\n";
        std::cout << (_2 + _2)(a, b) << "\n";
        
        (std::cout << _1 << " + " << _2 << " = " << _1 + _2 << "\n")(a, b);
    }

    {
        //Assign each int in the vector to the value of 1, then print the integers
        //  in the next pass
        std::vector<int>    v(5);

        std::for_each(v.begin(), v.end(), _1 = 1);
        std::for_each(v.begin(), v.end(), std::cout << _1 << "\n");
    }

    {
        //Assign each int to the next value of i, beginning with 0.  Display the
        //  values on the second pass
        std::vector<int>    v(5);
        int                 i = 0;

        //The following doesn't work as expected
        std::for_each(v.begin(), v.end(), _1 = i++);
        std::for_each(v.begin(), v.end(), std::cout << _1 << "\n");

        //The following does work as expected
        std::for_each(v.begin(), v.end(), _1 = var(i)++);
        std::for_each(v.begin(), v.end(), std::cout << _1 << "\n");
    }

    {
        //Assign and display in the same pass
        std::vector<int>    v(5);
        int                 i = 0;

        std::for_each(v.begin(), v.end(), (_1 = var(i)++, std::cout << _1 << "\n"));
    }

    {
        //Assign each value to the address of i, and then sort based on values.
        //  Note that this is a toy example, and the sorting won't do a thing
        //  since each pointer is pointing to the same location
        std::vector<int *>  v(5);
        int                 i = 0;

        std::for_each(v.begin(), v.end(), _1 = &i);
        std::sort(v.begin(), v.end(), *_1 > *_2);
    }

    {
        //Assign each int in the vecto to an increasing i, and then call DisplayInt
        //  for each int on the second pass
        std::vector<int>    v(5);
        int                 i = 0;

        std::for_each(v.begin(), v.end(), _1 = var(i)++);
        std::for_each(v.begin(), v.end(), bind(DisplayInt, _1));
    }

    {
        //Assign each Object's i_ member variable to an increasing i, then
        //  call the Object's Display method on the second pass
        std::vector<Object> v(5);
        int                 i = 0;

        std::for_each(v.begin(), v.end(), bind(&Object::i_, _1) = var(i)++);
        std::for_each(v.begin(), v.end(), bind(&Object::Display, _1));
    }
        
    {
        //Assign each int to an increasing i, and then attempt to output
        //  each int followed by a space
        std::vector<int>    v(5);
        int                 i = 0;

        std::for_each(v.begin(), v.end(), _1 = var(i)++);

        //This doesn't work as expected
        std::for_each(v.begin(), v.end(), std::cout << ' ' << _1);  
        std::cout << "\n";

        //This does work as expected
        std::for_each(v.begin(), v.end(), std::cout << constant(' ') << _1);    
        std::cout << "\n";
    }

    {
        //Allocate a new object for each pointer in the vector, set the objects i_ member variable,
        //  then call the Object's Display member function on the first pass.  Delete
        //  each object in the vector on the second pass
        std::vector<Object *>  v(5);
        int                    i = 0;

        std::for_each(v.begin(), v.end(), (_1 = bind(new_ptr<Object>()), bind(&Object::i_, _1) = var(i)++, bind(&Object::Display, _1)));
        std::for_each(v.begin(), v.end(), bind(delete_ptr(), _1));
    }

    {
        //Assign each int in the vector to an increasing i, and then
        //  use an if_then_else condition to display a odd/even message on
        //  the second pass
        std::vector<int>        v(5);
        int                     i = 0;

        std::for_each(v.begin(), v.end(), _1 = var(i)++);
        std::for_each(v.begin(), v.end(), if_then_else(_1 & 1, std::cout << _1 << " is odd\n", std::cout << _1 << " is even\n"));
    }

    return(0);
}