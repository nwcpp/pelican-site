//////////////////////////////////////////////////////////////////////////////
//
//  thread.cpp
//      Examples using boost's (www.boost.org) thread library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.10.2002 6:00 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <boost/thread/thread.hpp>
#include <boost/thread/recursive_mutex.hpp>
#include <boost/thread/xtime.hpp>
#include <boost/bind.hpp>

#include <iostream>

//////////////////////////////////////////////////////////////////////////////
//  Internal Global Variables
static boost::mutex                     sg_mutex;
static boost::recursive_mutex           sg_rmutex;
static boost::timed_mutex               sg_tmutex;

//////////////////////////////////////////////////////////////////////////////
void HelloWorldThread(void)
{
    std::cout << "Hello Threaded World!\n";
}

void HelloWorldThreadWithArgument(const char *pszString)
{
    std::cout << "Hello Threaded World! (" << pszString << ")\n";
}

void single_thread_example(void)
{
    {
        std::cout << "Before thread...\n";
        boost::thread           thd(&HelloWorldThread);

        thd.join();
        std::cout << "After thread...\n";
    }

    {
        std::cout << "Before thread...\n";
        boost::thread           thd(boost::bind(&HelloWorldThreadWithArgument, "argumented version"));

        thd.join();
        std::cout << "After thread...\n";
    }
}

//////////////////////////////////////////////////////////////////////////////
static const unsigned long      NUM_THREADS = 4;
static const unsigned long      MAX_COUNT   = 20;

static unsigned long                    sg_ulCount = 0;

void ThreadProc(void)
{
    std::cout << "In ThreadProc...\n";
    while(sg_ulCount < MAX_COUNT)
    {
        //Only one thread can increment and output at a time...
        boost::mutex::scoped_lock       lk(sg_mutex);

        std::cout << sg_ulCount++ << "\n";
    }
    std::cout << "Out ThreadProc...\n";
}

void multi_thread_example(void)
{
    boost::thread_group             thds;
    for(unsigned long ulCtr = 0; ulCtr < NUM_THREADS; ++ulCtr)
        thds.create_thread(&ThreadProc);

    thds.join_all();
}

//////////////////////////////////////////////////////////////////////////////
void Func2(void)
{
    //Acquire a lock on the mutex that may have already been acquired in Func1
    boost::recursive_mutex::scoped_lock         lock(sg_rmutex);

    std::cout << "In Func2...\n";
    std::cout << "Out Func2...\n";
}

void Func1(void)
{
    boost::recursive_mutex::scoped_lock         lock(sg_rmutex);

    std::cout << "In Func1...\n";
    Func2();
    std::cout << "Out Func1...\n";
}

void recursive_mutex_example(void)
{
    Func1();
    Func2();
}

//////////////////////////////////////////////////////////////////////////////
void TimedFunc1(void)
{
    boost::timed_mutex::scoped_lock         lock(sg_tmutex);
    boost::xtime                            xTime;

    //Wait for 7 seconds
    std::cout << "Waiting for 7 seconds...\n";

    boost::xtime_get(&xTime, boost::TIME_UTC);
    xTime.sec += 7;

    boost::thread::sleep(xTime);
    std::cout << "Done waiting!\n";
}

void timed_example(void)
{
    boost::thread                               thd(&TimedFunc1);

    //Wait for the thread to acquire the lock on the mutex
    boost::xtime                                xTime;

    boost::xtime_get(&xTime, boost::TIME_UTC);
    xTime.sec += 1;
    boost::thread::sleep(xTime);

    boost::timed_mutex::scoped_timed_lock       lock(sg_tmutex, false);
    
    //Wait for 3 seconds to lock
    boost::xtime_get(&xTime, boost::TIME_UTC);
    xTime.sec += 3;

    if(lock.timed_lock(xTime) == false)
        std::cout << "Lock not acquired!\n";

    if(lock.locked() == false)
        lock.lock();

    std::cout << "Lock acquired!\n";
}

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    std::cout << "\nsingle_thread_example:\n";
    single_thread_example();

    std::cout << "\nmulti_thread_example:\n";
    multi_thread_example();

    std::cout << "\nrecursive_mutex_example:\n";
    recursive_mutex_example();

    std::cout << "\ntimed_example:\n";
    timed_example();

    std::cout << "\ncondition_example:\n";
    condition_example();

    return(0);
}