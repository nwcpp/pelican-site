//////////////////////////////////////////////////////////////////////////////
//
//  concept_check.cpp
//      Example using boost's (www.boost.org) concept_check library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.9.2002 12:42 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <vector>
#include <algorithm>
#include <iterator>

#include <boost/concept_check.hpp>

#include "../MyObject.h"

//////////////////////////////////////////////////////////////////////////////
#if defined TEST_FUNCTION
    //////////////////////////////////////////////////////////////////////////////
    #ifdef TEST_STL
        #define MYCOPY std::copy
    #else
        #define MYCOPY MyCopy
    #endif

    template <typename InputIterator, typename OutputIterator>
    OutputIterator MyCopy(InputIterator begin, InputIterator end, OutputIterator result)
    {
        boost::function_requires<boost::InputIteratorConcept<InputIterator> >();
        boost::function_requires<boost::OutputIteratorConcept<OutputIterator, std::iterator_traits<InputIterator>::value_type> >();

        return(std::copy(begin, end, result));
    }

    void Example(void)
    {
        std::vector<int>        v;

        MYCOPY(v.begin(), v.end(), v);
    }

#elif defined TEST_CLASS
    //////////////////////////////////////////////////////////////////////////////
    template <typename IntegerType>
    class MyClass
    {
        BOOST_CLASS_REQUIRE(IntegerType, boost, IntegerConcept);
    };

    void Example(void)
    {
        MyClass<int>        mc1;
        MyClass<MyObject>   mc2;
    }

#elif defined TEST_CUSTOM_CLASS
    //////////////////////////////////////////////////////////////////////////////
    template <typename ClassWithFooMethod>
    struct ClassWithFooMethodConcept
    {
        void constraints(void)
        {
            c.Foo();
        }
        ClassWithFooMethod  c;
    };

    void Example(void)
    {
        boost::function_requires<ClassWithFooMethodConcept<MyObject> >();
        boost::function_requires<ClassWithFooMethodConcept<int> >();
    }

#else
    //////////////////////////////////////////////////////////////////////////////
    #pragma message("*****  No test was defined, everything will compile as expected")

    void Example(void) {}
#endif

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    Example();
    return(0);
}