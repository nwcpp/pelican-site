//////////////////////////////////////////////////////////////////////////////
//
//  regex.cpp
//      Examples using boost's (www.boost.org) RegEx library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.10.2002 5:59 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <boost/regex.hpp>
#include <iostream>

//////////////////////////////////////////////////////////////////////////////
//  Internal Global Variables
static boost::regex         sg_emailExpr("([a-z|0-9]+)@([a-z|0-9]+)\\.([a-z|0-9]{2,3})");       //This is not a very
                                                                                                //  good expression,
                                                                                                //  but it works for an
                                                                                                //  example

//////////////////////////////////////////////////////////////////////////////
//  Misc Utility Functions
bool DisplayResults(const boost::cmatch &results)
{
    for(int iCtr = 0; iCtr < static_cast<int>(results.size()); ++iCtr)
        std::cout << "    [" << iCtr << "]: \"" << std::string(results[iCtr].first, results[iCtr].second) << "\"\n";

    return(true);
}

//////////////////////////////////////////////////////////////////////////////
void regex_match_example(void)
{
    const char *            ppszStrings[] = { "a@b.com", 
                                              "foo", 
                                              "bar", 
                                              "test@123", 
                                              "test@123.a", 
                                              "test@123.ab", 
                                              "test@123.abc", 
                                              "test@123.abcd",
                                              "I am going to send a message to a@b.com today" };
    boost::cmatch           results;

    const char **           ptr;
    const char **           pEnd;

    ptr = ppszStrings;
    pEnd = ptr + sizeof(ppszStrings) / sizeof(*ppszStrings);

    while(ptr < pEnd)
    {
        std::cout << *ptr << ": ";

        if(boost::regex_match(*ptr, results, sg_emailExpr))
        {
            std::cout << "matches.\n";
            DisplayResults(results);
        }
        else
            std::cout << "doesn't match.\n";

        ++ptr;
    }
}

//////////////////////////////////////////////////////////////////////////////
void regex_search_example(void)
{
    const char *            ppszStrings[] = { "a@b.com",
                                              "pre test@.com post",
                                              "pre test@123.abcd post",
                                              "I am going to send a message to a@b.com today" };
    boost::cmatch           results;

    const char **           ptr;
    const char **           pEnd;

    ptr = ppszStrings;
    pEnd = ptr + sizeof(ppszStrings) / sizeof(*ppszStrings);

    while(ptr < pEnd)
    {
        std::cout << *ptr << ": ";

        if(boost::regex_search(*ptr, results, sg_emailExpr))
        {
            std::cout << "matches.\n";
            DisplayResults(results);
        }
        else
            std::cout << "doesn't match.\n";

        ++ptr;
    }
}

//////////////////////////////////////////////////////////////////////////////
void regex_grep_example(void)
{
    const char *            ppszStrings[] = { "a@b.com, b@c.com, c@d.com",
                                              "pre test@.com post",
                                              "pre test@123.abcd post",
                                              "I am going to send a message to a@b.com today" };

    const char **           ptr;
    const char **           pEnd;
    int                     iRetVal;

    ptr = ppszStrings;
    pEnd = ptr + sizeof(ppszStrings) / sizeof(*ppszStrings);

    while(ptr < pEnd)
    {
        std::cout << *ptr << ":\n";
        
        iRetVal = boost::regex_grep(DisplayResults,
                                    *ptr,
                                    sg_emailExpr);

        std::cout << iRetVal << " matches\n";
        ++ptr;
    }
}

//////////////////////////////////////////////////////////////////////////////
void regex_format_example(void)
{
    boost::cmatch           results;

    if(boost::regex_match("a@b.com", results, sg_emailExpr))
        std::cout << boost::regex_format(results, "'$1' '$2' '$3'") << "\n";
}

//////////////////////////////////////////////////////////////////////////////
void regex_merge_example(void)
{
    std::string             str("a@b.com, b@c.com, test@.a, c@d.com");

    std::cout << boost::regex_merge(str, sg_emailExpr, "'$1' '$2' '$3'") << "\n";
}

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    std::cout << "\nregex_match_example:\n";
    regex_match_example();

    std::cout << "\nregex_search_example:\n";
    regex_search_example();

    std::cout << "\nregex_grep_example:\n";
    regex_grep_example();

    std::cout << "\nregex_format_example:\n";
    regex_format_example();

    std::cout << "\nregex_merge_example:\n";
    regex_merge_example();

    return(0);
}