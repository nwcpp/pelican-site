//////////////////////////////////////////////////////////////////////////////
//
//  ref.cpp
//      Examples using boost's (www.boost.org) ref library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.9.2002 2:15 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <boost/bind.hpp>
#include "../MyObject.h"

//////////////////////////////////////////////////////////////////////////////
void Function(const MyObject &obj)
{
    obj.Foo();
}

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    MyObject            obj;

    std::cout << "\nNot using ref:\n";
    boost::bind(Function, obj)();

    std::cout << "\nUsing ref:\n";
    boost::bind(Function, boost::ref(obj))();

    return(0);
}