//////////////////////////////////////////////////////////////////////////////
//
//  smart_ptr.cpp
//      Examples using boost's (www.boost.org) Smart ptr library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.9.2002 12:52 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <boost/scoped_ptr.hpp>
#include <boost/scoped_array.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/shared_array.hpp>
#include <boost/weak_ptr.hpp>

#include "../MyObject.h"

//////////////////////////////////////////////////////////////////////////////
static const unsigned long ARRAY_SIZE = 3;

//////////////////////////////////////////////////////////////////////////////
void scoped_ptr_example(void)
{
    boost::scoped_ptr<MyObject>         pOuter(new MyObject("Outer"));

    pOuter->Foo();
    
    {
        boost::scoped_ptr<MyObject>     pInner(new MyObject("Inner"));

        pInner->Foo();
        pInner->Bar();
    }

    pOuter->Bar();
}

//////////////////////////////////////////////////////////////////////////////
void scoped_array_example(void)
{
    boost::scoped_array<MyObject>       pArray(new MyObject[ARRAY_SIZE]);

    pArray[0].SetString("First Object");
    pArray[0].Foo();

    pArray[2].Foo();
    pArray[2].Bar();
}

//////////////////////////////////////////////////////////////////////////////
void shared_ptr_func(boost::shared_ptr<MyObject> ptr)
{
    ptr->Foo();
    ptr->Bar();
}

void shared_ptr_example(void)
{
    boost::shared_ptr<MyObject>         p1(new MyObject("Object"));
    boost::shared_ptr<MyObject>         p2;

    p1->Foo();
    p2 = p1;
    p2->Bar();

    shared_ptr_func(p1);
    shared_ptr_func(p2);
}

//////////////////////////////////////////////////////////////////////////////
void shared_array_func(boost::shared_array<MyObject> pArray)
{
    pArray[0].Foo();
    pArray[0].Bar();
}

void shared_array_example(void)
{
    boost::shared_array<MyObject>         p1(new MyObject[ARRAY_SIZE]);
    boost::shared_array<MyObject>         p2;

    p1[0].Foo();
    p2 = p1;
    p2[0].Bar();

    shared_array_func(p1);
    shared_array_func(p2);
}

//////////////////////////////////////////////////////////////////////////////
void weak_ptr_example(void)
{
    boost::shared_ptr<MyObject>         pObject(new MyObject);
    boost::weak_ptr<MyObject>           pWeak(pObject);

    if(boost::shared_ptr<MyObject> ptr = boost::make_shared(pWeak))
        ptr->SetString("Alive #1");

    //In a multi-threaded environment, the memory pointed to by pObject may 
    //  have been deleted.  In this example, we will just reset the object
    //  to get the same effect.
    pObject.reset();

    if(boost::shared_ptr<MyObject> ptr = boost::make_shared(pWeak))
        //This will never be executed
        ptr->SetString("Alive #2");

    //At this pint, pObject's string has been set to "Alive #1".  We should see
    //  this in the destructor.
}

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    std::cout << "\nscoped_ptr_example:\n";
    scoped_ptr_example();

    std::cout << "\nscoped_array_example:\n";
    scoped_array_example();

    std::cout << "\nshared_ptr_example:\n";
    shared_ptr_example();

    std::cout << "\nshared_array_example:\n";
    shared_array_example();

    std::cout << "\nweak_ptr_example:\n";
    weak_ptr_example();

    return(0);
}