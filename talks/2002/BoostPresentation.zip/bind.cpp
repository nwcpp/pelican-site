//////////////////////////////////////////////////////////////////////////////
//
//  bind.cpp
//      Examples using boost's (www.boost.org) bind library
//
//  Author:
//      David Brownell
//
//  Created:
//      11.9.2002 1:43 PM
//
//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2002 David Brownell
//
//  Permission to use, copy, modify, distribute and sell this software
//  and its documentation for any purpose is hereby granted without
//  fee, provided that the above copyright notice appears in all copies
//  and that both the copyright notice and this permission notice
//  appear in supporting documentation.  It is provided 'as is' without
//  express or implied warranty.
//
//////////////////////////////////////////////////////////////////////////////
#include <boost/bind.hpp>
#include <boost/function.hpp>

#include "../MyObject.h"

#include <algorithm>
#include <vector>

//////////////////////////////////////////////////////////////////////////////
void MyAddFunction(int a, int b) { std::cout << a << " + " << b << " = " << a + b << "\n"; }

void function_example(void)
{
    int     value = 4;

    boost::bind(MyAddFunction, _1, 2)(value);
    boost::bind(MyAddFunction, 3, _1)(value);
    boost::bind(MyAddFunction, _1, _1)(value);
    boost::bind(MyAddFunction, 1, 2)();
}

//////////////////////////////////////////////////////////////////////////////
struct IsOddFunctionObject
{
    bool operator()(int i) { return(i & 1); }
};

void function_operator_example(void)
{
    int                     value = 3;
    IsOddFunctionObject     fo;

    std::cout << boost::bind<bool>(fo, _1)(value) << "\n";
    std::cout << boost::bind<bool>(fo, 2)() << "\n";
}

//////////////////////////////////////////////////////////////////////////////
void FancyDisplay(char *pre, char *post, int i)
{
    std::cout << pre << i << post;
}

void STL_algorithm_example(void)
{
    std::vector<int>        v;

    for(int ctr = 0; ctr < 10; ++ctr)
        v.push_back(ctr);

    std::for_each(v.begin(), v.end(), boost::bind(FancyDisplay, "The value is: ", ".\n", _1));
}

//////////////////////////////////////////////////////////////////////////////
//  In this example, we have a multipass algorithm, and need to display the 
//  status for each portion of the algorithm.  Unfortunately, the IterateItems
//  function doesn't know anything about the other steps, and only knows how
//  to output status for the current step.  In this case, we are using bind
//  to convert from the Status function (which has knowledge of all the steps)
//  to the IterateItems function (which only has knowledge of a single step),
//  using boost::function to "glue" the two functions together.
void Status(int iStep, char a, char b)
{
    std::cout << "Step #" << iStep << ": " << a << " of " << b << "\n";
}

void IterateItems(char begin, char end, const boost::function<void, char, char> &status)
{
    while(begin <= end)
        status(begin++, end);
}

void boost_function_example(void)
{
    for(unsigned char ctr = 0; ctr < 3; ++ctr)
        IterateItems('a', 'c', boost::bind(Status, ctr + 1, _1, _2));
}

//////////////////////////////////////////////////////////////////////////////
void FooFunc(void) { std::cout << "FooFunc\n"; }

void boost_function_member_function_example(void)
{
    boost::function0<void>      func;
    MyObject                    obj("MyObject");

    func = FooFunc;
    func();

    func = boost::bind(MyObject::Foo, &obj);
    func();
}

//////////////////////////////////////////////////////////////////////////////
int main(void)
{
    std::cout << "\nfunction_example:\n";
    function_example();

    std::cout << "\nfunction_operator_example:\n";
    function_operator_example();

    std::cout << "\nSTL_algorithm_example:\n";
    STL_algorithm_example();

    std::cout << "\nboost_function_example:\n";
    boost_function_example();

    std::cout << "\nboost_function_member_function_example:\n";
    boost_function_member_function_example();

    return(0);
}