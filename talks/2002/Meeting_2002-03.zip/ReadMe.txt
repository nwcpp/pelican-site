These are the files from the talk given 3/13/2002 by
Matt Griscom at the Northwest C++ Users' Group meeting.
http://nwcpp.org

For the HTML version of the presentation:
You may have to copy the directory tree at the directory "HTML"
and below to a temporary, un-compressed directory, for this to
work. I suspect that this is only an issue with Windows XP.

The code samples here were developed using
Visual Studio .Net beta 2

The PowerPoint presentation is version
PowerPoint 2000.