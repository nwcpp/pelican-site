// This is the main project file for VC++ application project

#include "stdafx.h"
#include "PrimeNumber.h"

#using <mscorlib.dll>

using namespace System;

int IsNumberPrime(int iCandidate)
{
    int bRetVal = 0; // FALSE
    CPrimeNumber * primeNumber =
        new CPrimeNumber(iCandidate);

    try
    {
        bRetVal = primeNumber->IsPrime();
    }

    catch (System::Exception * ex)
    {
        System::Console::WriteLine("Exception caught: ",
            ex->Message );
    }

    return bRetVal;
}

int main(void)  
{
    try
    {
        // Standard limit for these time trials
        //  is 10,000,000
        const int iLimit = 100000;
        System::IO::StreamWriter * sr =
            new System::IO::StreamWriter(
            "managedCppPrimes.txt",
            /*append*/ false);
        System::DateTime dtStart =
            System::DateTime::get_Now();

        for (int iTrialNum = 0;
            iTrialNum < iLimit;
            iTrialNum++)
        {
            if (IsNumberPrime(iTrialNum) )
            {
                System::String * str =
                    iTrialNum.ToString();
                sr->WriteLine(str);
            }
        }

        System::String * strNotice =
            new System::String("The limit of ");
        strNotice = System::String::Concat(strNotice,
            iLimit.ToString(), " was reached.");
        sr->WriteLine(strNotice);
        System::DateTime dtFinish =
            System::DateTime::get_Now();
        System::TimeSpan ts = dtFinish - dtStart;

        long lSecondsElapsed = (long)
            (ts.get_Ticks() / ts.TicksPerSecond );
        strNotice =
            System::String::Concat("Time elapsed: ",
            lSecondsElapsed.ToString(), " seconds." );
        sr->WriteLine(strNotice);
        sr->Close();
    }

    catch (System::Exception * ex)
    {
        System::Console::WriteLine("Exception caught: ",
            ex->Message);
    }

	return 0;
}