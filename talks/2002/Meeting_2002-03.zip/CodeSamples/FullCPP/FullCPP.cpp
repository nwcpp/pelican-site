// FullCPP.cpp : Defines the entry point for the console
//  application.
//

#include "stdafx.h"
#include "PrimeNumber.h"
#include <time.h>
#include <iostream>
#include <fstream>

#using <mscorlib.dll>

int IsNumberPrime(int iCandidate)
{
    int bRetVal = 0; // FALSE
    CPrimeNumber * pPrimeNumber = NULL;

    try
    {
        pPrimeNumber = new CPrimeNumber(iCandidate);
        bRetVal = pPrimeNumber->IsPrime();
    }

    catch (int iEx)
    {
        std::cout << "Integral exception value " << iEx
            << "caught here." << std::endl;
    }

    if ( (void*) 0 < pPrimeNumber)
    {
        delete pPrimeNumber;
    }

    return bRetVal;
}

int _tmain(int argc, _TCHAR* argv[])
{
    try
    {
        // Standard limit for these time trials
        //  is 10,000,000
        const int iLimit = 100000;
        std::ofstream* pOutputFile =
            new std::ofstream("fullCppPrimes.txt",
            std::ios_base::out);
        time_t timeStart, timeEnd;
        time(&timeStart);

        for (int iTrialNum = 0; iTrialNum < iLimit;
            iTrialNum++)
        {
            if (IsNumberPrime(iTrialNum) )
            {
                *pOutputFile << iTrialNum << std::endl;
            }
        }

        time(&timeEnd);
        *pOutputFile << "The limit of " << iLimit
            << " was reached." << std::endl;
        *pOutputFile << "Time elapsed: "
            << difftime(timeEnd ,timeStart)
            << " seconds." << std::endl;
        pOutputFile->close();
    }

    catch (...)
    {
        std::cout << "Some exception caught here."
            << __FILE__ << __LINE__ << std::endl;
    }

	return 0;
}

// end of file
