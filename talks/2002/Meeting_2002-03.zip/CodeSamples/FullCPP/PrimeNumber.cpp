// File: PrimeNumber.cpp
//
// This is the implementation file for the CPrimeNumber
//  class

#include "stdafx.h"
#include "PrimeNumber.h"
#include <math.h>

#using <mscorlib.dll>

// Only one public constructor
CPrimeNumber::CPrimeNumber(int iNum)
{
    m_iNum = iNum;
}

// This uses the simplest (and not very efficient)
//  algorithm to determine whether the number contained
//  by this class is prime or not. FALSE is returned
//  if not, TRUE if the number is prime
int CPrimeNumber::IsPrime(void)
{
    int iRetVal = 1;

    if (m_iNum > 1)
    {
        int iDivisor = 2;

        for (iDivisor = 2;
            iDivisor <= sqrt( (double) m_iNum) + 0.5;
            iDivisor++)
        {
            if (0 == (m_iNum % iDivisor) )
            {
                iRetVal = 0;
                break;
            }
        }
    }
    else
    {
        iRetVal = 0; // Negative numbers, 0, 1
                     //  are not prime in the sense
                     //  used here
    }

    return iRetVal;
}

// end of file