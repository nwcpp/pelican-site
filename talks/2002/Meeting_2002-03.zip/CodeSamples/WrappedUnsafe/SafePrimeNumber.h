// File: SafePrimeNumber.h
//
// This is the header file for the CSafePrimeNumber class
#if !defined MTG_SAFEPRIMENUMBER_H_SEEN
#define MTG_SAFEPRIMENUMBER_H_SEEN

#include "UnsafePrimeNumber.h"
#using <mscorlib.dll>

__gc class CSafePrimeNumber
{
public:
    // Only one public constructor
    CSafePrimeNumber(int iNum);

    ~CSafePrimeNumber(void);

    // This uses the simplest (and not very efficient) algorithm to determine whether
    //  the number contained by this class is prime or not. FALSE is returned if not,
    //  TRUE if the number is prime
    int IsPrime(void);

private:

    CUnsafePrimeNumber * pUnsafePrimeNumber;
};

#endif // MTG_SAFEPRIMENUMBER_H_SEEN
// end of file
