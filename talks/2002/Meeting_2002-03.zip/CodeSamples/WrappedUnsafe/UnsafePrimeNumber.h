// File: UnsafePrimeNumber.h
//
// This is the header file for the CUnsafePrimeNumber class
#if !defined MTG_UNSAFEPRIMENUMBER_H_SEEN
#define MTG_UNSAFEPRIMENUMBER_H_SEEN

__nogc class CUnsafePrimeNumber
{
public:
    // Only one public constructor
    CUnsafePrimeNumber(int iNum);

    // This uses the simplest (and not very efficient) algorithm to determine whether
    //  the number contained by this class is prime or not. FALSE is returned if not,
    //  TRUE if the number is prime
    int IsPrime(void);

private:
    // Make no-arg constructor private, no implementation
    //CUnsafePrimeNumber(void);

    int m_iNum;
};

#endif // MTG_UNSAFEPRIMENUMBER_H_SEEN
// end of file
