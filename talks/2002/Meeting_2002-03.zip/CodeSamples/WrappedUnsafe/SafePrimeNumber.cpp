// File: SafePrimeNumber.cpp
//
// This is the implementation file for the CSafePrimeNumber
//  class
#include "stdafx.h"
#include "SafePrimeNumber.h"

#using <mscorlib.dll>

// Only one public constructor
CSafePrimeNumber::CSafePrimeNumber(int iNum)
{
    pUnsafePrimeNumber = new CUnsafePrimeNumber(iNum);
}

CSafePrimeNumber::~CSafePrimeNumber(void)
{
    if (0 < pUnsafePrimeNumber)
    {
        delete pUnsafePrimeNumber;
        pUnsafePrimeNumber = 0;
    }
}

// This uses the simplest (and not very efficient)
//  algorithm to determine whether the number contained
//  by this class is prime or not. FALSE is returned
//  if not, TRUE if the number is prime
int CSafePrimeNumber::IsPrime(void)
{
    return pUnsafePrimeNumber->IsPrime();
}

// end of file