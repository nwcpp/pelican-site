// File: PrimeNumber.h
//
// This is the header file for the CPrimeNumber class
#if !defined MTG_PRIMENUMBER_H_SEEN
#define MTG_PRIMENUMBER_H_SEEN

#using <mscorlib.dll>

__nogc class CPrimeNumber
{
public:
    // Only one public constructor
    CPrimeNumber(int iNum);

    // This uses the simplest (and not very efficient) algorithm to determine whether
    //  the number contained by this class is prime or not. FALSE is returned if not,
    //  TRUE if the number is prime
    int IsPrime(void);

private:
    // Make no-arg constructor private, no implementation
    //CPrimeNumber(void);

    int m_iNum;
};

#endif // MTG_PRIMENUMBER_H_SEEN
// end of file
