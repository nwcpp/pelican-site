#pragma once

// A helper class to interact with the GPU. Currently this class is basically implemented as a singleton and assumed only one GPU will be available.
// It will always initialize to the first GPU enumerated if more than one GPU is present.

#include "cuda_runtime.h"

class Gpu
{
public:
	Gpu();
	~Gpu();

	static int ComputeCapabilityMajor();
	static int ComputeCapabilityMinor();
	static int CudaCoreCountPerMultiProcessor();
	static int CudaCores();
	static int MaxThreadsPerBlock();
	static int MaxThreadsPerMultiProcessor();
	static int MultiProcessorCount();

private:
	static bool initialized;
	static cudaDeviceProp deviceProp;
};

