#include <iostream>

#include "Gpu.h"

using namespace std;

bool Gpu::initialized {false};
cudaDeviceProp Gpu::deviceProp;

const int DEFAULT_GPU = 0;

Gpu::Gpu() {
    if (!initialized) {
        cudaError_t cudaStatus = cudaSetDevice(DEFAULT_GPU);
        if (cudaStatus != cudaSuccess) {
            cout << "cudaSetDevice failed with error: " << cudaGetErrorString(cudaStatus) << endl;
        }
        else
        {
            cudaGetDeviceProperties(&deviceProp, DEFAULT_GPU);
            initialized = true;
        }

       cout << "GPU Stats:" << endl;
       cout << "    Compute Capability: " << ComputeCapabilityMajor() << "." << ComputeCapabilityMinor() << endl;
       cout << "    " << MultiProcessorCount() << " Multiprocessors, " << CudaCoreCountPerMultiProcessor() << " CUDA Cores / MP, " << CudaCores() << " CUDA Cores" << endl;
       cout << "    MaxThreadsPerMultiProcessor: " << MaxThreadsPerMultiProcessor() << endl;
       cout << "    MaxThreadsPerBlock: " << MaxThreadsPerBlock() << endl;
    }
}

Gpu::~Gpu() {
    if (initialized) {
        initialized = false;
        // cudaDeviceReset must be called before exiting in order for profiling and
        // tracing tools such as Nsight and Visual Profiler to show complete traces.
        cudaError_t cudaStatus = cudaDeviceReset();
        if (cudaStatus != cudaSuccess) {
            cout << "cudaDeviceReset failed with error: " << cudaGetErrorString(cudaStatus) << endl;
        }
    }
}

int Gpu::ComputeCapabilityMajor() {
    if (initialized) {
        return deviceProp.major;
    }
    else {
        cout <<  "ComputeCapabilityMajor called before initialization" << endl;
        return 0;
    }
}

int Gpu::ComputeCapabilityMinor() {
    if (initialized) {
        return deviceProp.minor;
    }
    else {
        cout << "ComputeCapabilityMinor called before initialization" << endl;
        return 0;
    }
}

int Gpu::CudaCoreCountPerMultiProcessor() {
    if (initialized) {
        int major = deviceProp.major;
        int minor = deviceProp.minor;
        // Defines for GPU Architecture types (using the SM version to determine
        // the # of cores per SM
        typedef struct {
            int SM;  // 0xMm (hexidecimal notation), M = SM Major version,
            // and m = SM minor version
            int Cores;
        } sSMtoCores;

        sSMtoCores nGpuArchCoresPerSM[] = {
            {0x30, 192},
            {0x32, 192},
            {0x35, 192},
            {0x37, 192},
            {0x50, 128},
            {0x52, 128},
            {0x53, 128},
            {0x60,  64},
            {0x61, 128},
            {0x62, 128},
            {0x70,  64},
            {0x72,  64},
            {0x75,  64},
            {0x80,  64},
            {0x86, 128},
            {0x87, 128},
            {0x89, 128},
            {0x90, 128},
            {-1, -1} };

        int index = 0;

        while (nGpuArchCoresPerSM[index].SM != -1) {
            if (nGpuArchCoresPerSM[index].SM == ((major << 4) + minor)) {
                return nGpuArchCoresPerSM[index].Cores;
            }

            index++;
        }
        return nGpuArchCoresPerSM[index - 1].Cores;
    }
    else {
        cout << "CudaCoreCountPerMultiProcessor called before initialization" << endl;
        return 0;
    }

}

int Gpu::MaxThreadsPerBlock() {
    if (initialized) {
        return deviceProp.maxThreadsPerBlock;
    }
    else {
        cout << "MaxThreadsPerBlock called before initialization" << endl;
        return 0;
    }
}

int Gpu::CudaCores() {
    return CudaCoreCountPerMultiProcessor() * MultiProcessorCount();
}

int Gpu::MaxThreadsPerMultiProcessor() {
    if (initialized) {
        return deviceProp.maxThreadsPerMultiProcessor;
    }
    else {
        cout << "MaxThreadsPerMultiProcessor called before initialization" << endl;
        return 0;
    }
}

int Gpu::MultiProcessorCount() {
    if (initialized) {
        return deviceProp.multiProcessorCount;
    }
    else {
        cout << "MultiProcessorCount called before initialization" << endl;
        return 0;
    }
}
