This is my own implementation of a meta reflection system.  Special thanks to Sean Middleditch (http://seanmiddleditch.com) and Chris Peters (DigiPen), both of whom showed me some of these tricks and inspired others.  This system is meant to be a sample to show how a meta data and reflection system could be implemented, however it is probably too incomplete for a production system.

Jeff Tucker
jjeff@digipen.edu