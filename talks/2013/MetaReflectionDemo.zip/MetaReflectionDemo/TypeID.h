#pragma once
#include "GUIDGenerator.h"

// useful for when type is undefined for some reason 
// e.g. asking for the type of a function argument that 
// does not exist (see MetaMethod.h)
struct NullType
{

};

class TypeID
{
public:
    TypeID() : 
      guid(GUIDGenerator::GetNextGuid())
    {

    }

    operator unsigned() const 
    {
        return guid;
    }
private:
    // avoid the temptation to make this const since default 
    // assignment operator will not be available so no
    // std::vector<TypeID> would be possible.  Could use 
    // std::vector<unsigned> instead but why bother?
    unsigned guid;
};

// unique ID for every type we ever want to know 
// about, even for those that have no MetaData 
// defined. 
template <typename T>
inline TypeID GetTypeID()
{
    static TypeID tid;
    return tid;
}

#define TYPEOF(T) GetTypeID<T>()
#define TYPEOFOBJECT(T) GetTypeID<decltype(T)>()