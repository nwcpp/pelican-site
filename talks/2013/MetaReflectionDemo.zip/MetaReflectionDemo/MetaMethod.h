#pragma once
#include "MetaProperty.h"
#include "Variant.h"

// functions are extremely similar and could even use the same base class


// we'll use this to store arguments for methods/functions here.
// functions are extremely similar to methods and can be implemented in 
// almost the same way
typedef std::vector<Variant> ArgList;

// same non-template base class as in MetaProperty so that we can store these in 
// a collection.  If you wanted to support things with return types, 
// it wouldn't be too much to add
class IMetaMethod
{
public:
    IMetaMethod(const char* n)
        : name(n)
    {

    }
    const char* Name() const { return name;}
    // number of arguments and their types is useful to
    // know
    virtual unsigned ArgCount() const = 0;
    virtual TypeID GetArgTypeByIndex(unsigned idx) = 0;
    virtual void Invoke(void* obj, ArgList& alist) = 0;

private:
    const char* name;
};

// this isn't totally necessary but I happen to like it, so
// really up to you.
template <int ARG_COUNT = 0>
class MetaMethodBase : public IMetaMethod
{
public:
    MetaMethodBase(const char* n, int ac) : IMetaMethod(n),
        argCount(ac)
    {

    }
    
    unsigned ArgCount() const { return argCount; }
    TypeID GetArgTypeByIndex(unsigned idx)
    {
        if(idx < ARG_COUNT)
        {
            return argTypes[idx];
        }
        else
        {
            return TYPEOF(NullType);
        }
    }

    virtual void Invoke(void* v, ArgList& alist)
    {
        // check that everything is ok
        if(alist.size() != argCount)
            return;

        if(!v)
            return;

        OnInvoke(v, alist);
    }
protected:
    TypeID argTypes[ARG_COUNT];
    // we'll use the template method pattern here to avoid
    // duplicating the argument verification code, that way we can 
    // just call this thing in derived classes.
    virtual void OnInvoke(void* v, ArgList& alist) = 0;
private:
    // we still need argCount or this won't work for methods with
    // no arguments
    unsigned argCount;

};

// without variadic template params, we need to have a new class for 
// each number of arguments.  MetaMethodBase allows us to minimize the 
// amount of code necessary.  
template <typename CLASS>
class VoidMethod : public MetaMethodBase<1>
{
public:
    // same idea as MetaProperty
    typedef  void (CLASS::*voidmethod)();
    
    VoidMethod(const char* n, voidmethod m)
        : MetaMethodBase(n, 0), myMethod(m)
    {
        // HACK: we want this to return NullType anyway, 
        // so let's just store that since we have to have 
        // something in the array and it's not useful
        // to have special one-off code when we can just make
        // this work.  
        argTypes[0] = TYPEOF(NullType);
    }

protected:
    void OnInvoke(void* v, ArgList& alist)
    {
        ((CLASS*)v->*myMethod)();
    }
    voidmethod myMethod;

};

template <typename CLASS, typename P0>
class MethodOneArg : public MetaMethodBase<1>
{
public:
    typedef void (CLASS::*methodOne)(P0);
    MethodOneArg(const char* n, methodOne m)
        : MetaMethodBase(n, 1), myMethod(m)
    {

    }
protected:
    void OnInvoke(void* v, ArgList& alist)
    {
        // we've already validated the type and number of args in alist
        // so this is all we need
        ((CLASS*)v->*myMethod)(alist[0].As<P0>());
    }
private:
    methodOne myMethod;
};

// these are convenient ways to create meta methods, especially since
// compiler will be able to infer types 
template <typename CLASS>
IMetaMethod* Bind(const char* str, void (CLASS::*classFunc)())
{
    return new VoidMethod<CLASS>(str, classFunc);
}

template <typename CLASS, typename P0>
IMetaMethod* Bind(const char* str, void (CLASS::*classFunc)(P0))
{
    return new MethodOneArg<CLASS, P0>(str, classFunc);
}

#define DECLARE_META_METHOD(CLASS, METHODNAME) do {\
    auto md = GETMETAFORTYPE(CLASS);\
    if(md) {md->AddMetaMethod(#METHODNAME, Bind(#METHODNAME, &CLASS::METHODNAME));}\
}while(false)

#define METHOD_BY_NAME(CLASS, METHODNAME) GETMETAFORTYPE(CLASS) == NULL ? NULL : (GETMETAFORTYPE(CLASS))->GetMethodByName(#METHODNAME)