#pragma once

// would be useful for all of these things
// to work
class FakeTestObject
{
public:
    int PublicIntProperty;
    void SetPublicIntProp(int v) { PublicIntProperty = v;}
    int GetPublicIntProp() { return PublicIntProperty; }
    void SetFloat(float f) { PrivateFloatProperty = f; }
    float GetFloat() { return PrivateFloatProperty; }
    void ClearProps() { PrivateFloatProperty = 0.f; PublicIntProperty = 0;}
private:
    float PrivateFloatProperty;
};
