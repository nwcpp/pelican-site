#pragma once
#include "TypeID.h"
#include "Variant.h"

// we need a non-template base class in order to be able to store these
// in some sort of collection.  we can use our variant here as well if
// we feel like it
class IMetaProperty
{
public:
    virtual std::string Serialize(void*) = 0;

    virtual Variant GetValue(void*) = 0;
    virtual void SetValue(void*, Variant v) = 0;
};

// intermediary class that we can push common functionality 
// into so that we avoid duplicated code
template<typename CLASS, typename FIELD>
class MetaBase : public IMetaProperty
{
public:
    MetaBase(const char* n, TypeID tid)
        : name(n), type(tid)
    {

    }

    // use derived get/set to make this simple
    Variant GetValue(void* obj)
    {
        Variant v(GetValue(*(CLASS*)obj));
        return v;
    }

    void SetValue(void* obj, Variant v)
    {
        SetValue(*(CLASS*)obj, v.As<FIELD>());
    }


    virtual FIELD GetValue(CLASS& obj) = 0;
    virtual void SetValue(CLASS& obj, FIELD val) = 0;

    // serialization is probably not the responsibility of this
    // class.  Good idea to refactor this later
    virtual std::string Serialize(void* v)
    {
        std::stringstream strstr;
        strstr << Name() << "=" << GetValue(*(CLASS*)v);
        return strstr.str();
    }

    TypeID Type() const { return type; }
    const char* Name() const { return name; }
private:
    const char* name;
    TypeID type;
};

// data member
template<typename CLASS, typename FIELD>
class MetaField : public MetaBase<CLASS, FIELD>
{
public:
    // read as PROPPTR is a pointer in the scope of CLASS, that
    // points to a FIELD.  This is just for convenience
    typedef FIELD CLASS::*PROPPTR;
    
    // need to get the appropriate pointer so 
    // probably best to grab that here
    MetaField(const char* n, PROPPTR p)
        : MetaBase(n, TYPEOF(FIELD)), ptr(p)
    {

    }

    // need an instance of the appropriate class
    // to use the pointer
    FIELD GetValue(CLASS& obj)
    {
        return obj.*ptr;
    }

    void SetValue(CLASS& obj, FIELD val)
    {
        obj.*ptr = val;
    }

private:
    PROPPTR ptr;

};

// property with getter/setter
template <typename CLASS, typename PROPERTY>
class MetaProperty : public MetaBase<CLASS, PROPERTY>
{
public:
    // read as:  GETTER is a pointer in the scope of CLASS to a method
    // that takes no arguments and returns a PROPERTY
    typedef  PROPERTY (CLASS::*GETTER)();
    // setter is similar
    typedef void (CLASS::*SETTER)(PROPERTY);

    MetaProperty(const char* name, GETTER g, SETTER s)
        : MetaBase(name, TYPEOF(PROPERTY)), getter(g), setter(s)
    {

    }

    PROPERTY GetValue(CLASS& obj)
    {
        // parens are necessary here, also for 
        // ->* operator if obj were a pointer
        return (obj.*getter)();
    }

    void SetValue(CLASS& obj, PROPERTY val)
    {
        (obj.*setter)(val);
    }

private:
    GETTER getter;
    SETTER setter;
};


// use the do{...}while(false) to avoid possible compiler issues depending on 
// how we use these.

#define DECLARE_FIELD(CLASS, FIELD) do { \
    MetaData* md = GETMETAFORTYPE(CLASS); \
    assert(md != NULL);\
    if(md) \
{ md->AddMetaProperty(#FIELD, new MetaField<CLASS, decltype( ((CLASS*)NULL)->FIELD)>(#FIELD, &CLASS::FIELD));} }\
    while(false)


#define DECLARE_PROPERTY(CLASS, FIELD, FIELDGETTER, FIELDSETTER) do { \
    MetaData* md = GETMETAFORTYPE(CLASS); \
    assert(md != NULL);\
    if(md) \
{ md->AddMetaProperty(#FIELD, new MetaProperty<CLASS, decltype( ((CLASS*)NULL)->FIELDGETTER())>(#FIELD, &CLASS::FIELDGETTER, &CLASS::FIELDSETTER));} }\
    while(false)

#define FIELD_BY_NAME(CLASS, FIELD) GETMETAFORTYPE(CLASS) == NULL ? NULL : dynamic_cast<MetaField<CLASS, decltype( ((CLASS*)NULL)->FIELD)>*>(GETMETAFORTYPE(CLASS)->GetFieldByName(#FIELD));
#define PROPERTY_BY_NAME(CLASS, FIELD) GETMETAFORTYPE(CLASS) == NULL ? NULL : dynamic_cast<MetaProperty<CLASS, decltype( ((CLASS*)NULL)->FIELD)>*>(GETMETAFORTYPE(CLASS)->GetFieldByName(#FIELD));