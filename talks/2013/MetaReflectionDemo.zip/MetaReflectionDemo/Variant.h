#pragma once
#include "TypeID.h"

// sample for the union defined below
struct Vec3
{
    Vec3()
    {

    }
    float x;
    float y;
    float z;
};

class Variant
{
public:

    template <typename T>
    Variant(T val)
    {
        type = GetTypeID<T>();
        As<T>() = val;
    }

    // grab the address of what's being stored
    // (doesn't matter which part of the union we 
    // use), cast it appropriately, then dereference it.
    // Will this work for all types?  Also, what about 
    // pointer ownership?  Will this work for asking for 
    // things as references?  You may need to potentially
    // specialize this thing for certain types also
    template <typename T>
    T& As()
    {
        return *(T*)(&intVal);
    }

    // make sure this is the correct type.  This
    // isn't strictly necessary since we can always verify
    // first with a call to Type(), but what if we want to 
    // know if the types can be cast safely if not the same,
    // e.g. float to double?  Some other lookup or 
    // possibly resolving the metadata might be 
    // useful here.
    template <typename T>
    bool SafeCast(T& val)
    {
        if(GetTypeID<T>() != Type())
        {
            return false;
        }
        else
        {
            val = As<T>();
            return true;
        }
    }

    TypeID Type() const { return type; }
    
private:
    TypeID type;
    // what types do we care about?  Remember that 
    // we only really care about making sure that this is 
    // the right size to hold whatever we're storing. 
    // also, do we always want these by 
    // value?  
    union 
    {
        int intVal;
        unsigned uintVal;
        float floatVal;
        // note:  If a constructor is defined, 
        // even if it has no arguments, we can't 
        // use it in a union (at least with this compiler)
        // so we have to use an anonymous struct like this:
        struct{
        Vec3 vector3;
        };
        void* ptrVal;
    };
};