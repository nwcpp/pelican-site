#pragma once

class GUIDGenerator
{
public:
    static unsigned GetNextGuid();
private:
    static unsigned curGuid;
};
