#include "stdafx.h"
#include "Variant.h"

TEST(VariantTest, VariantCanHoldValueType)
{
    int i = 42;
    Variant v(i);
    EXPECT_EQ(TYPEOF(int), v.Type());
    int j = v.As<int>();
    EXPECT_EQ(i, j);
}

TEST(VariantTest, SafeCastToImproperTypeFails)
{
    bool ok = false;
    int i = 42;
    Variant v(i);
    char result = 0;
    ok = v.SafeCast<char>(result);
    EXPECT_FALSE(ok);
}

TEST(VariantTest, SafeCastToProperTypeWorks)
{
    bool ok = false;
    int i = 42;
    Variant v(i);
    int result = 0;
    ok = v.SafeCast<int>(result);
    ASSERT_TRUE(ok);
    EXPECT_EQ(i, result);
}

TEST(VariantTest, AsCorrectValTypeWorks)
{
    float i = 4.2;
    Variant v(i);
    EXPECT_EQ(TYPEOF(float), v.Type());    
    EXPECT_FLOAT_EQ(4.2, v.As<float>());
}
