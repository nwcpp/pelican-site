#pragma once
#include "TypeID.h"
#include <unordered_map>
#include <type_traits>
#include "MetaProperty.h"
#include "MetaMethod.h"
class IMetaMethod;

// we'll use this to hold the MetaData, whatever info we need
class MetaData
{
public:
    // defaulting base type in the constructor means we won't need
    // two constructors, so less typing
    MetaData(const char* n, TypeID tid, TypeID bt = TYPEOF(NullType))
        : name(n), type(tid), baseType(bt)
    {

    }

    // TODO: destructor

    // type, name, asking if something is derived from, 
    // could also have something to determine if we can 
    // safely cast something as this type as well
    TypeID Type() const { return type; }
    const char* Name() const { return name; }
    bool DerivedFrom(TypeID tid) const { return tid == baseType;}
    
    // simple, just add to a map.  Ponder whether or not 
    // you would want to replace a thing already defined.
    // pretty much the same for all of these, getter just does 
    // a lookup.
    void AddMetaProperty(std::string name, IMetaProperty* prop)
    {
        auto iter = propertyMap.find(name);
        if(iter == propertyMap.end())
        {
            propertyMap[name] = prop;
        }
    }

    IMetaProperty* GetFieldByName(std::string name)
    {
        auto iter = propertyMap.find(name);
        if(iter != propertyMap.end())
        {
            return iter->second;
        }
        else
        {
            return NULL;
        }
    }
    
    // methods are the same as properties
    void AddMetaMethod(std::string name, IMetaMethod* method)
    {
        if(auto iter = methodMap.find(name) == methodMap.end())
        {
            methodMap[name] = method;
        }
    }

    IMetaMethod* GetMethodByName(std::string name)
    {
        auto iter = methodMap.find(name);
        if(iter != methodMap.end())
        {
            return iter->second;
        }
        else
        {
            return NULL;
        }
    }


    // this is pretty easy to do, but the actual 
    // serialization is probably not the responsibility of 
    // this class.  Many possible solutions
    void Serialize(void* obj, std::ostream& strm)
    {
        strm << Name() << "{" << std::endl;

        auto iter = propertyMap.begin();
        for(;iter != propertyMap.end(); ++iter)
        {
            strm << iter->second->Serialize(obj) << std::endl;
        }

        strm << "}" << std::endl;
    }


private:
    const char* name;
    TypeID type;
    TypeID baseType;
    std::unordered_map<std::string, IMetaProperty*> propertyMap;
    std::unordered_map<std::string, IMetaMethod*> methodMap;
};

// this is one possibility- a metaregistry that just stores things
// based on their type.  I like this because it's fairly simple and allows me to 
// instantiate things in a particular order instead of in whatever the compiler feels
// like.  That way, I can define a base class first with methods/properties, and then
// when I register a derived class, I can copy over the public/protected methods/properties so 
// that I only have to register them on the base class.  This is convenient but
// be careful of how you ordering things.  It's possible to use placeholders
// and then resolve things later but this is complicated.  Also, 
// any lookup you do will have the overhead of finding thigs in the 
// metamap.  Might not be a major perf hit but what if we do this
// hundreds or thousands of times?
//
//class MetaRegistry
//{
//public:
//    static MetaRegistry& GetMetaRegistry() { return metaReg; }
//    void AddMetaData(MetaData* md)
//    {
//        if(auto metamapiter = metamap.find(md->Type()) != metamap.end())
//            metamap[md->Type()] = md;
//    }
//private:
//    static MetaRegistry metaReg;
//    std::unordered_map<TypeID, MetaData*> metamap;
//};
//
//
//MetaRegistry MetaRegistry::metaReg;



// this is another way that we can store the metadata for each class.  It's 
// simpler, but in some ways it's less powerful.  No searching though, so 
// this will be a lot faster than the metaregistry.  Credit to Sean Middleditch for
// this trick
template <typename T>
class MetaSingleton
{
public:
    static MetaData* GetMeta() { return &metaData; }
private:
    static MetaData metaData;
};

// this is necessary as well.  You'd also need similar derived classes
// for const, references, etc.
template <typename T>
class MetaSingleton<T*> : public MetaSingleton<T>
{

};

// This gives us the virtual metadata that we need
template <typename T, typename B>
class DynamicMetaClass : public B
{
public:
    virtual MetaData* GetMeta() { return MetaSingleton<T>::GetMeta(); }
};

 // useful
#define DECLAREMETA(T) MetaData MetaSingleton<T>::metaData(#T, TYPEOF(T))
// also useful for defining derived class.  This won't handle multiple inheritance
// but since multiple inheritance is generally bad and best avoided, that scenario is 
// really not worth bothering with here
#define DECLAREDYNAMICMETA(T, BASE) MetaData MetaSingleton<T>::metaData(#T, TYPEOF(T), TYPEOF(BASE))

// this is the start of a trick to figure out 
// if a GetMeta() method exists or if we have to go straight to 
// the metaregistry or factory.  This is 
// substitution failure is not an error (SFINAE).  If 
// you are unfamiliar with this, it's probably best to 
// google for other examples as well.
template <typename T>
class MetaIsDynamic
{
    // what we want is two different methods so that
    // one will be chosen by the compiler as an exact 
    // match when a GetMeta() method exists, and 
    // the other to match anything else as well 
    // as to always be a worse match than the other
private:
    // this is just defined so that we have some 
    // sort of type that we can identify.  It could
    struct not_dynamic{};

    // is dynamic- if a class has a GetMeta method on it, 
    // then we want this to be the match that the compiler
    // chooses.
    template <typename U>
    static char check( decltype(((U*)(NULL))->GetMeta())* );
    
    // is not dynamic- no such method exists, so this is chosen.
    // note that the ellipsis will always be the worst possibly match
    // by the compiler.
    template <typename U>
    static not_dynamic check(...);
public:
    // what we want is for this value to be correct at compile time depending
    // on what the class has defined.  What we can do is try to match our check function
    // by its return type and the type that we're passing to it.  If the type of 
    // T has the correct method, this will match something that returns a char.  If not, 
    // it will return the not_dynamic struct so we just examine the type and now
    // this value will be correct.
    static const bool value = !std::is_same<not_dynamic, decltype(check<T>(NULL))>::value;


};

// now we need a way to figure out if our meta is dynamic or not somehow and 
// either call that method, or lookup in the metaregistry or singleton
template <typename MT>
class MetaLookup
{
public:
    // enable_if will define "type" to the second parameter if the 
    // first one is true, otherwise it will not be defined.  Therefore, 
    // we want this to be defined only if the class has a GetMeta() method.
    // our MetaIsDynamic struct will do exactly that
    template <typename U>
    static typename std::enable_if<MetaIsDynamic<U>::value, MetaData*>::type resolve(U& obj)
    {
        return obj.GetMeta();
    }

    // this will have "type" defined if meta is not dynamic, so only one of these will
    // actually match.  The other one won't compile, which is fine, since the compiler 
    // finds one that does compile and ignores the other one.
    template <typename U>     
    static typename std::enable_if<!MetaIsDynamic<U>::value, MetaData*>::type resolve(U& obj)
    {
        return MetaSingleton<U>::GetMeta();
    }

    // now for whatever object gets passed in, we just call our resolve function
    // and the compiler will figure out which version of resolve to call
    static MetaData* GetMeta(MT& obj){ return resolve<MT>(obj); }
};

// we need this too incase the thing is a pointer 
// (comment this out and see what happens)
template <typename MT> 
class MetaLookup<MT*> : public MetaLookup<MT>
{
public:
    static MetaData* GetMeta(MT* object) {return MetaLookup<MT>::GetMeta(*object); }

};

// really want this to work for classes that have GetMeta() method OR if 
// we have to lookup the meta from the metaregistry or meta singleton (either way 
// is similar here)
#define GETMETA(T) MetaLookup<decltype(T)>::resolve(T)

// if we know the type, it's not a problem anyway
#define GETMETAFORTYPE(T)  MetaSingleton<T>::GetMeta()