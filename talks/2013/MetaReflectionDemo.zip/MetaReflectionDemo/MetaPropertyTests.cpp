#include "stdafx.h"
#include <sstream>
#include "TestDoubles.h"
#include "MetaProperty.h"
#include "MetaData.h"
class MetaFieldTest : public ::testing::Test
{
public:
    MetaFieldTest()
    {

    }

protected:
    virtual void SetUp()
    {
        SUT = FIELD_BY_NAME(FakeTestObject, PublicIntProperty);
        fakeTestObj.PublicIntProperty = 42;
    }

    virtual void TearDown()
    {
    }

    FakeTestObject fakeTestObj;
    //MetaProperty<FakeTestObject, int>* SUT;
    MetaField<FakeTestObject, int>* SUT;

};



TEST_F(MetaFieldTest, MetaPropertyIsDefinable)
{    
    ASSERT_FALSE(SUT == NULL);
    EXPECT_EQ(TYPEOF(int), SUT->Type());
}

TEST_F(MetaFieldTest, CanGetValue)
{
    ASSERT_FALSE(SUT == NULL);
    int test = 0;
    test = SUT->GetValue(fakeTestObj);
    EXPECT_EQ(42, test);
    EXPECT_EQ(42, fakeTestObj.PublicIntProperty);
}

TEST_F(MetaFieldTest, CanSetValue)
{
    ASSERT_FALSE(SUT == NULL);
    SUT->SetValue(fakeTestObj, 10);
    EXPECT_EQ(10, fakeTestObj.PublicIntProperty);
}

TEST_F(MetaFieldTest, ToString)
{
    std::string str;
    str = SUT->Serialize(&fakeTestObj);
    EXPECT_STREQ("PublicIntProperty=42", str.c_str());
}

TEST(MetaPropertyTest, GetterSetterWorks)
{
    FakeTestObject fakeTestObject;
    fakeTestObject.PublicIntProperty = 42;
    MetaBase<FakeTestObject, int>* SUT = dynamic_cast<
        MetaBase<FakeTestObject, int>*>
        (
            GETMETA(fakeTestObject)->GetFieldByName("PublicIntProp")
            );
    int test = 0;
    test = SUT->GetValue(fakeTestObject);
    EXPECT_EQ(42, test);

    SUT->SetValue(fakeTestObject, 10);
    EXPECT_EQ(10, fakeTestObject.PublicIntProperty);
}

TEST(MetaPropetyTest, VariantGetterSetterWorks)
{
    FakeTestObject fakeTestObject;
    fakeTestObject.PublicIntProperty = 42;
    
    auto SUT = GETMETA(fakeTestObject)->GetFieldByName("PublicIntProp");
    int test = 0;
    Variant v = SUT->GetValue(&fakeTestObject);

    EXPECT_EQ(42, v.As<int>());

    v = Variant(10);
    SUT->SetValue(&fakeTestObject, v);
    EXPECT_EQ(10, fakeTestObject.PublicIntProperty);
}