#include "stdafx.h"
#include "MetaData.h"
#include "MetaMethod.h"
#include "TestDoubles.h"

class MetaMethodTest : public ::testing::Test
{
public:
    MetaMethodTest()
    {

    }

protected:
    virtual void SetUp()
    {
        //SUT = new MetaMethodOneArg<FakeTestObject, int>("SetPublicIntProp", &FakeTestObject::SetPublicIntProp);
        SUT = METHOD_BY_NAME(FakeTestObject, ClearProps);
        fakeTestObj.PublicIntProperty = 42;
    }

    virtual void TearDown()
    {
        //  delete SUT;
    }

    //MetaMethodOneArg<FakeTestObject, int>* SUT;
    IMetaMethod* SUT;
    FakeTestObject fakeTestObj;
};

TEST_F(MetaMethodTest, MetaMethodIsDefinable)
{
    ASSERT_TRUE(SUT != NULL);
    EXPECT_STREQ( "ClearProps", SUT->Name());
    
}

TEST_F(MetaMethodTest, ArgCountIsAccurate)
{
    EXPECT_EQ(0, SUT->ArgCount());
}

TEST_F(MetaMethodTest, ValidArgTypeIsAccurate)
{
    EXPECT_EQ(TYPEOF(NullType), SUT->GetArgTypeByIndex(0));
}

TEST_F(MetaMethodTest, GetArgTypeGreaterThanNumberOfArgsIsNullType)
{
    EXPECT_EQ(TYPEOF(NullType), SUT->GetArgTypeByIndex(0));
}

TEST_F(MetaMethodTest, InvokeCallsMethod)
{
    EXPECT_EQ(fakeTestObj.PublicIntProperty, 42);
    ArgList alist;
    SUT->Invoke(&fakeTestObj, alist);
    EXPECT_EQ(fakeTestObj.PublicIntProperty, 0);
}

TEST(MetaMethodTestOneArg, InvokeOneArgWorks)
{
    FakeTestObject fto;
    fto.SetFloat(5.f);
    EXPECT_FLOAT_EQ(5.f, fto.GetFloat());
    auto SUT = METHOD_BY_NAME(FakeTestObject, SetFloat);
    ArgList alist;
    Variant v1(8.f);
    alist.push_back(v1);
    SUT->Invoke(&fto, alist);
    EXPECT_FLOAT_EQ(8.f, fto.GetFloat());
}