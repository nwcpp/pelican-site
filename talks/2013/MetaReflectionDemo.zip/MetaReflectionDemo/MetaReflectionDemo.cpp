// MetaReflectionDemo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "MetaProperty.h"
#include "MetaData.h"

int _tmain(int argc, _TCHAR* argv[])
{
    ::testing::InitGoogleTest(&argc, argv);
    ::testing::InitGoogleMock(&argc, argv);
    
    DECLARE_FIELD(FakeTestObject, PublicIntProperty);
    DECLARE_PROPERTY(FakeTestObject, PrivateFloatProp, GetFloat, SetFloat);
    DECLARE_PROPERTY(FakeTestObject, PublicIntProp, GetPublicIntProp, SetPublicIntProp);
    DECLARE_META_METHOD(FakeTestObject, ClearProps);
    DECLARE_META_METHOD(FakeTestObject, SetFloat);
    int q = RUN_ALL_TESTS();
    std::cout << "tests complete."  << std::endl;
    
    std::cout << "running serialization demo" << std::endl;
    FakeTestObject fto;
    fto.SetPublicIntProp(42);
    fto.SetFloat(10.f);
    // some sort of meta declaration

    MetaData* md = GETMETA(fto);
    md->Serialize(&fto, std::cout);

    /*
            expected output (something like this):
            FakeTestObject {
                PublicIntProperty = 42,
                PrivateFloatProperty = 10.0
            }
    */

    std::cout << "serialization complete, press any key to exit, any other key to continue" << std::endl;
    std::cin.get();
	return q;
}
