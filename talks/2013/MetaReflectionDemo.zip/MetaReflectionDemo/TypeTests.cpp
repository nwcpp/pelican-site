#include "stdafx.h"
#include "TypeID.h"
#include "MetaData.h"

TEST(MetaData, TypeIDOfTwoTypesIsDifferent)
{
    TypeID t1 = TYPEOF(int);
    TypeID t2 = TYPEOF(FakeTestObject);
    EXPECT_NE(t1, t2);  
}

TEST(MetaData, TypeIDOfSameTypeIsSame)
{
    TypeID t1 = TYPEOF(int);
    TypeID t2 = TYPEOF(int);
    EXPECT_EQ(t1, t2);
}


DECLAREMETA(FakeTestObject);

TEST(MetaData, CanGetMetaForClass)
{
    FakeTestObject fto;
    MetaData* SUT = GETMETA(fto);
    ASSERT_TRUE(SUT != NULL);

    EXPECT_EQ(SUT->Type(), TYPEOF(FakeTestObject));
    EXPECT_STREQ("FakeTestObject", SUT->Name());
}


// we need to have a way to get the meta data for a derived class, so 
// some sort of virtual GetMeta() is going to be required that can be 
// implemented by the derived class to return the correct value

// one possibility is to add this:
#define DYNAMICMETA(T) virtual MetaData* GetMeta() { return GETMETAFORTYPE(T); }

class FakeBaseClass
{
public:
    // We need this to exist somehow:
    virtual MetaData* GetMeta() { return GETMETAFORTYPE(FakeBaseClass); }
    //DYNAMICMETA(FakeBaseClass)
};

// something like this is also a possibility; it's your choice
class FakeDerivedClass : public DynamicMetaClass<FakeDerivedClass, FakeBaseClass>
{
public:
   //virtual MetaData* GetMeta() { return GETMETAFORTYPE(FakeBaseClass); }
};

DECLAREMETA(FakeBaseClass);
DECLAREDYNAMICMETA(FakeDerivedClass, FakeBaseClass);

TEST(MetaData, CanGetMetaForDerivedClass)
{
    FakeDerivedClass fdc;
    FakeBaseClass fto;
    FakeBaseClass* ptr = &fdc;
    
    MetaData* SUT = MetaLookup<decltype(ptr)>::GetMeta(ptr);  // GETMETA(ptr);
    ASSERT_TRUE(SUT != NULL);

    EXPECT_EQ(SUT->Type(), TYPEOF(FakeDerivedClass));
    EXPECT_TRUE(SUT->DerivedFrom(TYPEOF(FakeBaseClass)));
}