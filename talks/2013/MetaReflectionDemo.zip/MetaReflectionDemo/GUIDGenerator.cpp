#include "stdafx.h"
#include "GUIDGenerator.h"
#include "windows.h"

unsigned GUIDGenerator::GetNextGuid()
{
    return InterlockedIncrement(&curGuid);
}

unsigned GUIDGenerator::curGuid = 0;
