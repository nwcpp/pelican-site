
BOOST_FOREACH
by Eric Niebler

The BOOST_FOREACH macro is a simple, intuitive and typesafe way to iterate
over a collection. It is inspired by similar looping constructs in other
languages, particularly C#. It is intended for inexperienced programmers who
do not know much about iterators, predicates and half-open sequences. It is
also useful for anybody who wants to type fewer characters when writing loops
over sequences. Its salient features are:

- It works over STL containers, arrays and null-terminated strings.

- Your loop variable can be a value or a reference. If it is a reference, then
  any changes you make to it get written through to the underlying sequence.
  
- It generates near-optimal code. That is, it is almost equivalent to the
  hand-coded equivalent.
  
- It behaves just like a for loop. That is, you can break, continue, goto or
  return out of the loop body.

The syntax is as follows:

  std::list<int> int_list;
  ...
  BOOST_FOREACH( int &i, int_list )
  {
      i += 10;
  }
  
Note that the loop variable, i, is a reference to the ints within int_list. You
can also declare your loop variable before the BOOST_FOREACH loop:

  int i;
  BOOST_FOREACH( i, int_list )
  {
      std::cout << i << std::endl;
      if ( -1 == i )
          break;  // this breaks out of the BOOST_FOREACH loop
  }

Acknowledgements

Many of the ideas for BOOST_FOREACH are described in the Nov 2003 C/C++ Users
Journal article by myself and Anson Tsao. That article describes how to
implement a FOR_EACH macro that works with .NET collections. BOOST_FOREACH is
a reimplementation of the original FOR_EACH macro that works with native type.
It also corrects a number of shortcomings of that implementation.
