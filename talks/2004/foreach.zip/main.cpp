#include <iostream>
#include <list>
#include "foreach.hpp"

using namespace std;

template<typename T>
void baz( list<T> & list_of_T )
{
    // an example of using BOOST_FOREACH with dependent types
    BOOST_FOREACH( T &t, list_of_T )
    {
        cout << t << endl;
    }
}

int main()
{
    list<int> int_list;
    int_list.push_back( 1 );
    int_list.push_back( 2 );
    int_list.push_back( 3 );

    // use BOOST_FOREACH with a STL container, and a reference as the
    // loop variable.
    BOOST_FOREACH( int &i, int_list )
    {
        cout << i << endl;
        ++i;
    }

    // use BOOST_FOREACH with dependent types
    baz( int_list );
    cout << endl;

    // use BOOST_FOREACH with a native array
    int int_array[] = {1,2,3};
    BOOST_FOREACH( int &i, int_array )
    {
        cout << i << endl;
        // modify the int in the array
        ++i;
    }
    BOOST_FOREACH( int i, int_array )
    {
        // write out the modified array
        cout << i << endl;
    }
    cout << endl;

    // iterate over characters in a std::string
    std::string str( "hello" );
    BOOST_FOREACH( char &ch, str )
    {
        cout << ch;
        // mutate the string
        ++ch;
    }
    cout << endl;
    BOOST_FOREACH( char ch, str )
    {
        cout << ch;
        // break and continue work as you would expect
        break;
    }
    cout << endl;
    cout << endl;

    // iterate over characters in a null-terminated string.
    char const * sz = "hello";
    BOOST_FOREACH( char const &ch, sz )
    {
        cout << ch;
    }
    cout << endl;
    cout << endl;

    typedef list<int>::iterator int_list_iter;
    int_list_iter begin = int_list.begin(), end = int_list.end();

    // use BOOST_FOREACH with a STL iterators, using in_range().
    BOOST_FOREACH( int i, ::boost::for_each::in_range( begin, end ) )
    {
        cout << i << endl;
    }
    cout << endl;

    // use BOOST_FOREACH with a std::pair of iterators
    std::pair<int_list_iter,int_list_iter> iter_pair( begin, end );
    BOOST_FOREACH( int i, iter_pair )
    {
        cout << i << endl;
    }
    cout << endl;


    return 0;
}
