/*
 * This file is licensed under the Mozilla Public License, v. 2.0.
 * You can obtain a copy of the license at http://mozilla.org/MPL/2.0/.
 *
 * Reference: Sections of this code were adapted from sample code that accompanies the book
 * _Learning Modern C++ for Finance_, Daniel Hanson, O'Reilly Publishers (2024)
 */

module;
#include <cassert>

export module EnginesAndDistributions;

import std;

export void default_random_engine()
{
	using std::vector, std::cout;

	cout << "\n*** default_random_engine() ***\n";

	// An engine requires an integer seed value, e.g. 100:
	std::default_random_engine def{100};	// Same as std::minstd_rand engine
											// (linear congruent generator) on MSVC and gcc

	for (int i = 0; i < 10; ++i)
	{
		// Random integers generated directly from the engine, 
		// accessed as a functor (implemented on each std lib engine):
		cout << def() << " ";	// 
	}
	cout << "\n\n";

	// MSVC: 2333906440 2882591512 1195587395 1769725799 1823289175 
	//       2260795471 3628285872 638252938 20267358 673068980
	// gcc:  1680700 330237489 1203733775 1857601685 594259709 
	//		 1923970613 1512819812 1903683451 1996387951 1007791729

	std::vector<double> unifs(10);

	// Use the default_random_engine with continuous
	// uniform distribution on [0, 1):	
	std::uniform_real_distribution<double> unif_rand_dist{0.0, 1.0};

	// Generate 10 uniform variates from [0.0, 1.0) and set
	// as elements in the vector 'unifs':
	for (double& x : unifs)
	{
		x = unif_rand_dist(def);
	}
	for (double& x : unifs)
	{
		cout << x << " ";
	}

	// MSVC:  0.186467 0.210108 0.45274 0.870143 0.063681 
	//        0.624312 0.523348 0.562296 0.0058172 0.307423
	// gcc:   0.941637 0.457211 0.970019 0.769819 0.684224 
	//        0.677271 0.0436495 0.692878 0.391896 0.119059 

	// See https://godbolt.org/z/3sxb96K6c for gcc version

	cout << "\n\n";
}

// Extra example not covered in presentation:
export void ranlux_and_continuous_unif_dist()
{
	using std::vector, std::cout;
	cout << "\n*** ranlux_and_continuous_unif_dist() ***\n";

	// Ranlux 48 engine:
	std::ranlux48 r48{419};
	cout << "ranlux48 integers generated directly from the engine:\n";
	for (int i = 0; i < 10; ++i)
	{
		// Positive integers generated directly from the engine:
		cout << r48() << " ";	// 
	}
	cout << "\n\n";

	std::vector<double> unifs(10);
	std::uniform_real_distribution<double> unif_rand_dist{0.0, 1.0};
	for (double& x : unifs)
	{
		x = unif_rand_dist(r48);
	}
	for (double& x : unifs)
	{
		cout << x << " ";
	}

	cout << "\n\n";
}

export void mersenne_twister_and_normal_dist()
{
	using std::cout;
	cout << "\n*** mersenne_twister_and_normal_dist() ***\n";

	// Non-deterministic seed (kernel-provided entropy source)
	std::random_device rd;
	std::mt19937_64 mt{rd()};
			
	// Default mean = 0 and std dev = 1
	std::normal_distribution<> st_norm_rand_dist{};
	std::vector<double> norms(10);
	// Generate 10 standard normal variates and set as elements in the vector 'norms':
	for (double& x : norms)
	{
		x = st_norm_rand_dist(mt);
	}
	for (double x : norms)
	{
		cout << x << " ";
	}

	cout << "\n\n";

}

// Extra example function not in presentation:
export void other_distributions()
{
	using std::cout;
	cout << "\n*** other_distributions() ***\n";

	std::vector<double> t_draws(10);
	std::vector<double> p_draws(10);
	std::mt19937_64 mt{25};

	std::student_t_distribution<> stu{3};
	std::poisson_distribution<> pssn{7.5};

	for (auto& x : t_draws)
	{
		x = stu(mt);
	}

	for (auto& x : p_draws)
	{
		x = pssn(mt);
	}

	cout << "random draws from t(3):\n";
	for (double x : t_draws)
	{
		cout << x << " ";
	}
	cout << "\n\n";

	cout << "random draws from Poisson(7.5):\n";
	for (double x : p_draws)
	{
		cout << x << " ";
	}
	cout << "\n\n";
}

export void monty_hall_paradox(unsigned long seed_car_pos, unsigned long seed_choice_pos, unsigned long n_sim)
{
	using std::cout, std::mt19937_64, std::uniform_int_distribution;
	cout << "\nmonty_hall_paradox(int seed_car_pos, int seed_choice_pos, int n_sim)\n\n";

	mt19937_64 mt_car{seed_car_pos};
	mt19937_64 mt_choice{seed_choice_pos};
	uniform_int_distribution<> ud{1, 3};

	int wins = 0;		// Number of wins (to be incremented)
	

	// Case where contestant does not change choice
	for (unsigned i = 1; i <= n_sim; ++i)	// n_sim = Number of simulations from input
	{
		if (ud(mt_choice) == ud(mt_car))
			++wins;	
	}

	cout << "Number of wins when staying with 1st choice = " << wins << "/" << n_sim << "\n";
	double stayPct = static_cast<double>(wins) / static_cast<double>(n_sim);
	cout << "Pct wins when staying with 1st choice = " << stayPct * 100.0 << "%" << "\n";

	wins = 0;		// Reset counter

	// Case where contestant *does* change choice
	for (unsigned i = 1; i <= n_sim; ++i)
	{
		if (ud(mt_choice) != ud(mt_car))
			++wins;	
	}

	cout << "\n" << "Number of wins when changing door number = " << wins << "/" << n_sim << "\n";
	double changePct = static_cast<double>(wins) / static_cast<double>(n_sim);
	cout << "Pct wins when changing door number = " << changePct * 100.0 << "%" << "\n\n";
}