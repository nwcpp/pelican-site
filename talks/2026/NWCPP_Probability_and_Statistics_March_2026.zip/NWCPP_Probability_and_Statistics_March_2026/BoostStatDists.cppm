/*
 * This file is licensed under the Mozilla Public License, v. 2.0.
 * You can obtain a copy of the license at http://mozilla.org/MPL/2.0/.
 *
 * Reference: This code was adapted from sample code that accompanies the book
 * _Learning Modern C++ for Finance_, Daniel Hanson, O'Reilly Publishers (2024)
 */

module;
#include <boost/math/distributions/students_t.hpp>
#include <boost/math/distributions/normal.hpp>
#include "std_non_central_t_distribution.h"


export module BoostStatDists;
import std;
//import std_non_central_t_distribution;

using boost::math::students_t;
using boost::math::normal;

export void normal_and_t_dist()
{
	using std::cout, std::format;
	using boost::math::students_t;
	using boost::math::normal;

	cout << "\nBoost Dists: normal_and_t_dist()\n";
	// Construct a students_t distribution with 4 degrees of freedom: 
	students_t t_dist{4};

	// Construct a normal distribution with mean 0 and variance 1:
	normal std_normal{0.0, 1.0};	// or default: normal std_normal{};

	cout << "Degrees of freedom for t-distribution = " << t_dist.degrees_of_freedom() << "\n";
	cout << "Mean of standard normal distribution = " << std_normal.mean() << "\n";
	cout << "Standard deviation of standard normal distribution = " 
		 << std_normal.standard_deviation() << "\n\n";

	double n_pdf = pdf(std_normal, 0.0);		// 0.3989
	double n_cdf = cdf(std_normal, 0.0);		// 0.5
	double t_pdf = pdf(t_dist, 0.0);			// 0.375
	double t_cdf = cdf(t_dist, 0.0);			// 0.5

	// The fifth percentile of the standard normal distribution:
	double norm_five_pctle = quantile(std_normal, 0.05);	// -1.64485

	// The 95th percentile of a t distribution with 4 dof:
	double t_95_pctle = quantile(t_dist, 0.95);				// 2.1318

	cout << format("Standard Normal: pdf(0) = {}, cdf(0) = {}, 5th percentile = {}\n",
		n_pdf, n_cdf, norm_five_pctle);

	cout << format("t distribution with 4 dof: pdf(0) = {}, cdf(0) = {}, 5th percentile = {}\n\n",
		t_pdf, t_cdf, t_95_pctle);
}

export void random_non_central_t_dist()
{
	using std::cout, std::format;
	cout << "\nBoost Dists: random_non_central_t_dist()\n";

	// Similar look and feel as functions in <random>:
	std::mt19937_64 mt{100};
	std_non_central_t_distribution<> st{3.0, -0.05};

	// Wrap in lambda for use in the generate algo:
	auto nc_t_gen = [&mt, &st]()
	{
		return st(mt);
	};

	// Generate random draws and place in a vector:
	std::vector<double> nc_t_vals(20);	// nc = non-central
	//std::ranges::generate(nc_t_vals, nc_t_gen);

	// Doesn't work either:
	std::generate(nc_t_vals.begin(), nc_t_vals.end(), nc_t_gen);

	cout << std::fixed << std::setprecision(4);
	// View results:
	for (auto s : nc_t_vals)
	{
		//cout << format("{} ", s);
		cout << s << " " << "\n";
	}

	cout << "\n\n";
}