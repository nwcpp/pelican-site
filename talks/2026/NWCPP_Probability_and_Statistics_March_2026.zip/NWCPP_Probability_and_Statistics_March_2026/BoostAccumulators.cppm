/*
 * This file is licensed under the Mozilla Public License, v. 2.0.
 * You can obtain a copy of the license at http://mozilla.org/MPL/2.0/.
 * 
 * Reference: This code was adapted from sample code that accompanies the book
 * _Learning Modern C++ for Finance_, Daniel Hanson, O'Reilly Publishers (2024)
 */

module;

#include <boost/accumulators/accumulators.hpp>
#include <boost/accumulators/statistics/stats.hpp>
#include <boost/accumulators/statistics/min.hpp>
#include <boost/accumulators/statistics/max.hpp>
#include <boost/accumulators/statistics/mean.hpp>
#include <boost/accumulators/statistics/variance.hpp>
#include <boost/accumulators/statistics/rolling_mean.hpp>
#include <boost/accumulators/statistics/rolling_variance.hpp>

export module BoostAccumulators;
import std;
namespace bacc = boost::accumulators;

// Extra example not covered in presentation:
export void min_max_accumulator()
{
	using std::cout;
	cout << "*** min_max_accumulator() ***" << "\n";

	bacc::accumulator_set<double, bacc::stats<bacc::tag::min, bacc::tag::max>> acc{};

	// push in some data . . .
	acc(5.8);
	acc(-1.7);
	acc(2.9);
	// Display the range
	cout << "(min, max) = (" << bacc::extract::min(acc) << ", " << bacc::extract::max(acc) << ")\n\n";

	// Now, add an element to acc (i.e., we are modifying its *state*),
	// and check that the min and max statistics also get updated:
	acc(524.0);

	// Display the range
	cout << "Updated: (min, max) = (" << bacc::extract::min(acc) << ", " << bacc::extract::max(acc) << ")\n";
	cout << "Type: " << typeid(bacc::extract::min(acc)).name() << "\n\n";
}

export void mean_and_var_accumulator()
{
	using std::cout;
	cout << "*** mean_and_var_accumulator() ***" << "\n";

	bacc::accumulator_set<double, bacc::stats<bacc::tag::mean, bacc::tag::variance>> mv_acc{};
	// push in some data . . .
	mv_acc(1.0);
	mv_acc(2.0);
	mv_acc(3.0);

	// Display the results:
	cout << "(mean, variance) = (" << bacc::extract::mean(mv_acc) << ", " << bacc::extract::variance(mv_acc) << ")\n";

	mv_acc(4.0);
	mv_acc(5.0);

	cout << "(mean, variance) = (" << bacc::extract::mean(mv_acc) << ", " << bacc::extract::variance(mv_acc) << ")\n";

	// Extra: Not in presentation
	mv_acc(16.0);
	mv_acc(17.0);
	mv_acc(18.0);

	cout << "(mean, variance) = (" << bacc::extract::mean(mv_acc) << ", " << bacc::extract::variance(mv_acc) << ")\n\n";
}

export void intro_rolling_windows()
{
	using std::cout;
	cout << "\n*** intro_rolling_windows() ***\n";
	cout << "Note that rolling_variance is based on the sample variance:\n\n ";

	// Note:  `rolling_variance` returns the *sample variance* (divide by n - 1),
	// while the `variance` accumulator in the previous example returns
	// the *population variance* (divide by n).
	bacc::accumulator_set<double, bacc::stats<bacc::tag::rolling_mean,
		bacc::tag::rolling_variance>> roll_acc{bacc::tag::rolling_window::window_size = 5};

	roll_acc(1.0);
	roll_acc(2.0);
	roll_acc(3.0);

	// These results are the mean and sample variance of the three elements
	// (we haven't yet reached the full five in the rolling window):
	cout << "(rolling mean, rolling variance) = (" << bacc::extract::rolling_mean(roll_acc) << ", "
		<< bacc::extract::rolling_variance(roll_acc) << ")\n\n";

	roll_acc(4.0);
	roll_acc(5.0);

	// We now get the rolling mean and sample variance of all five values:
	cout << "(rolling mean, rolling variance) = (" << bacc::extract::rolling_mean(roll_acc) << ", "
		<< bacc::extract::rolling_variance(roll_acc) << ")\n\n";

	roll_acc(16.0);
	roll_acc(17.0);
	roll_acc(18.0);

	// Finally, we get the rolling mean and sample variance of the last five values:
	cout << "(rolling mean, rolling variance) = (" << bacc::extract::rolling_mean(roll_acc) << ", "
		<< bacc::extract::rolling_variance(roll_acc) << ")\n\n";
}

export void rolling_windows_vector_data()
{
	using std::cout;
	cout << "\n*** intro_rolling_windows() ***\n";
	cout << std::fixed << std::setprecision(2);

	// Series of 25 closing daily prices:
	std::vector<double> prices
	{
		100.00, 103.49, 102.82, 106.86, 104.91,
		107.38, 107.46, 111.01, 112.01, 114.11,
		116.91, 121.74, 120.04, 120.24, 120.12,
		120.61, 121.31, 119.25, 118.11, 120.36,
		117.36, 119.12, 119.36, 123.54, 123.42
	};

	// Take moving average and moving variance of most recent 5 prices
	// => rolling_window::window_size = 5
	bacc::accumulator_set<double, bacc::stats<bacc::tag::rolling_mean, bacc::tag::rolling_variance>>
		prices_acc(bacc::tag::rolling_window::window_size = 5);

	// Load prices for days 1-10:
	auto iter = prices.cbegin();
	auto end = iter + 10;
	int day = 0;
	for (; iter != end; ++iter)
	{
		++day;
		cout << "day  = " << day << "; price = " << *iter << "\n";
		prices_acc(*iter);
	}
	cout << "\n";

	cout << "Moving average and moving variance of last five out of first 10 prices: "
		<< bacc::extract::rolling_mean(prices_acc) << ", "
		<< bacc::extract::rolling_variance(prices_acc) << "\n\n";	
}