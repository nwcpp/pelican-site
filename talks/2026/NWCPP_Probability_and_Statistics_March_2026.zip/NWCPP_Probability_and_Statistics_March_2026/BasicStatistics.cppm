/*
 * This file is licensed under the Mozilla Public License, v. 2.0.
 * You can obtain a copy of the license at http://mozilla.org/MPL/2.0/.
 */

module;
#include <P1708/statistics.hpp>

export module BasicStatistics;
import std;

export void basic_statistics_examples()
{
	using std::cout, std::format;
	cout << "\nbasic_statistics_examples(): means, variances, std deviations\n\n";

	std::vector<double> v;
	v.reserve(20);

	std::mt19937_64 mt{42};
	std::normal_distribution<> nd{};		// N(0, 1)
	std::ranges::generate_n(std::back_inserter(v), v.capacity(), [&]
		{
			return nd(mt); 
		}
	);

	double mean_val = std::mean(v);
	double pop_variance = std::variance(v, false);
	double samp_variance = std::variance(v, true);	
	double pop_std_dev = std::standard_deviation(v, false);
	double samp_std_dev = std::standard_deviation(v);	// default: sample = true
	double samp_skewness = std::skewness(v);	// default: sample = true
	double samp_kurtosis = std::kurtosis(v, {true, true});	// sample = true
															// excess kurtosis = true
	samp_kurtosis = std::kurtosis(v);	// default: sample = true, excess kurtosis = true

	std::vector<int> w{15, -20, 25, 32, -18, -22, 5, -10, 10, -6,
		15, -20, 25, 32, -18, -22, 5, -10, 10, -6};
	double wgt_mean = std::mean(v, w);

	// Parallel execution policy is also an option:
	wgt_mean = std::mean(std::execution::par, v, w);

	std::vector<double> u;
	u.reserve(20);
	
	std::ranges::generate_n(std::back_inserter(u), u.capacity(), [&]
		{
			return nd(mt);
		}
	);

	// Parallel execution policy is also an option:
	double samp_covariance = std::covariance(std::execution::par, v, u);

	cout << format("arith mean = {}\npopulation variance = {}\n"
		"sample variance = {}\npopulation std dev = {}\nsample std dev ={}\n"
		"sample skewness = {}\nsample kurtosis = {}\nweighted mean = {}\nsample covariance = {}\n\n",
		mean_val, pop_variance, samp_variance, pop_std_dev, samp_std_dev,
		samp_skewness, samp_kurtosis, wgt_mean, samp_covariance);

}

