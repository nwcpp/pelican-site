/*
 * This file is licensed under the Mozilla Public License, v. 2.0.
 * You can obtain a copy of the license at http://mozilla.org/MPL/2.0/.
 */

#include <boost/math/distributions/binomial.hpp>
#include <pcg/pcg_random.hpp>
#include <xoshiro/XoshiroCpp.hpp>
#include <P1708/statistics.hpp>
#include <vector>
#include <iostream>

import std;
import EnginesAndDistributions;
import BoostStatDists;
import PCG_And_Xoshiro;
import MCOptionExamplesParallel;
import BasicStatistics;
import BoostAccumulators;


int main()
{
	// Standard Library pseudo-random number generation
	default_random_engine();
	ranlux_and_continuous_unif_dist();
	mersenne_twister_and_normal_dist();

	other_distributions();
	monty_hall_paradox(319, 258, 2500);

	// Boost Statistical Distributions:
	normal_and_t_dist();
	random_non_central_t_dist();

	// PCG and Xoshiro:
	pcg_example();
	xoshiro_example();

	// Monte Carlo Option Valuation Performance Tests
	mc_option_examples_parallel();

	// Boost Accumulators
	min_max_accumulator();
	mean_and_var_accumulator(); 
	intro_rolling_windows();
	rolling_windows_vector_data();

	// P1708 Basic Statistics:
	basic_statistics_examples();
}