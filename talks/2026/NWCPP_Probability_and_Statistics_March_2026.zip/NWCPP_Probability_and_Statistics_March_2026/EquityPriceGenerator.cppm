/*
 * This file is licensed under the Mozilla Public License, v. 2.0.
 * You can obtain a copy of the license at http://mozilla.org/MPL/2.0/.
 *
 * Reference: This code was adapted from sample code that accompanies the book
 * _Learning Modern C++ for Finance_, Daniel Hanson, O'Reilly Publishers (2024)
 */

module;
#include <cmath>
#include <pcg/pcg_random.hpp>
#include <xoshiro/XoshiroCpp.hpp>

export module EquityPriceGenerator;

import std;

export class EquityPriceGenerator
{
public:
	EquityPriceGenerator(double spot, int num_time_steps,
		double time_to_expiration, double volatility, double rf_rate, double div_rate);

	std::vector<double> operator()(int seed) const;

private:
	double spot_;
	int num_time_steps_;
	double time_to_expiration_;
	double volatility_;
	double rf_rate_;		// Continuous risk-free rate
	double div_rate_;		// Continuous dividend rate
	double dt_;				// dt_ = "delta t"
};


EquityPriceGenerator::EquityPriceGenerator(double spot, int num_time_steps,
	double time_to_expiration, double volatility, double rf_rate, double div_rate) :
	spot_{spot}, num_time_steps_{num_time_steps}, time_to_expiration_{time_to_expiration},
	volatility_{volatility}, rf_rate_{rf_rate}, div_rate_{div_rate},
	dt_{time_to_expiration / num_time_steps} {
}

std::vector<double> EquityPriceGenerator::operator()(int seed) const
{
	std::vector<double> v;
	v.reserve(num_time_steps_ + 1);

	// ** Compare std::mt19937_64 vs PCG pcg64_fast vs XoshiroCpp::Xoshiro256PlusPlus **
	// Uncomment the engine you wish to use, and comment out the other two:
	
	// Std Lib Mersenne Twister 64
	std::mt19937_64 rng{static_cast<unsigned long>(seed)};
	// PCG:
	//pcg64_fast rng{seed};
	// Xoshiro:
	//XoshiroCpp::Xoshiro256PlusPlus rng{static_cast<unsigned long>(seed)};

	std::normal_distribution<> nd;

	auto new_price = [this](double previous_equity_price, double norm)
		{
			double price{0.0};

			double exp_arg_01 = (rf_rate_ - div_rate_ -
				((volatility_ * volatility_) / 2.0)) * dt_;
			double exp_arg_02 = volatility_ * norm * sqrt(dt_);
			price = previous_equity_price * std::exp(exp_arg_01 + exp_arg_02);

			return price;
		};

	v.push_back(spot_);				// put initial equity price into the 1st position in the vector
	double equity_price = spot_;

	for (int i = 1; i <= num_time_steps_; ++i)	// i <= num_time_steps_ since we need a price 
		// at the end of the final time step.
	{
		equity_price = new_price(equity_price, nd(rng));	// norm = nd(rng)
		v.push_back(equity_price);
	}

	return v;
}
