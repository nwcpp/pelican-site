/*
 * This file is licensed under the Mozilla Public License, v. 2.0.
 * You can obtain a copy of the license at http://mozilla.org/MPL/2.0/.
 *
 * Reference: This code was adapted from sample code that accompanies the book
 * _Learning Modern C++ for Finance_, Daniel Hanson, O'Reilly Publishers (2024)
 */

export module Payoffs;
import std;

export class Payoff
{
public:
	virtual double payoff(double price) const = 0;
	virtual std::unique_ptr<Payoff> clone() const = 0;
	virtual ~Payoff() = default;
};

export class CallPayoff final : public Payoff
{
public:
	CallPayoff(double strike);
	double payoff(double price) const override;
	std::unique_ptr<Payoff> clone() const override;		// clone() now returns a unique_ptr<Payoff>,
	// not unique_ptr<CallPayoff>

private:
	double strike_;
};

export class PutPayoff final : public Payoff
{
public:
	PutPayoff(double strike);
	//double operator()(double spot) const override;
	double payoff(double price) const override;
	std::unique_ptr<Payoff> clone() const override;		// clone() now returns a unique_ptr<Payoff>,
	// not unique_ptr<PutPayoff>

private:
	double strike_;
};

// --- CallPayoff implementation ---
CallPayoff::CallPayoff(double strike) :strike_{strike} {}

double CallPayoff::payoff(double spot) const
{
	return std::max(spot - strike_, 0.0);
}

std::unique_ptr<Payoff> CallPayoff::clone() const
{
	return std::make_unique<CallPayoff>(*this);
}


// --- PutPayoff implementation ---
PutPayoff::PutPayoff(double strike) :strike_{strike} {}

double PutPayoff::payoff(double spot) const
{
	return std::max(strike_ - spot, 0.0);
}

std::unique_ptr<Payoff> PutPayoff::clone() const
{
	return std::make_unique<PutPayoff>(*this);
}


