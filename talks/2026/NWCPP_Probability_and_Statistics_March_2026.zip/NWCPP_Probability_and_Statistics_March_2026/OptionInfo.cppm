/*
 * This file is licensed under the Mozilla Public License, v. 2.0.
 * You can obtain a copy of the license at http://mozilla.org/MPL/2.0/.
 *
 * Reference: This code was adapted from sample code that accompanies the book
 * _Learning Modern C++ for Finance_, Daniel Hanson, O'Reilly Publishers (2024)
 */

export module OptionInfo;

import Payoffs;
import std;

export class OptionInfo
{
public:
	OptionInfo(std::unique_ptr<Payoff> payoff, double time_to_exp);
	double option_payoff(double spot) const;
	double time_to_expiration() const;
	void swap(OptionInfo& rhs) noexcept;

	OptionInfo(const OptionInfo& rhs);
	OptionInfo& operator =(const OptionInfo& rhs) noexcept;

	// Remaining Rule of Five:
	OptionInfo(OptionInfo&& rhs) = default;					// Default move constructor
	OptionInfo& operator =(OptionInfo&& rhs) = default;		// Default move assignment

	~OptionInfo() = default;								// Default destructor

private:
	std::unique_ptr<Payoff> payoff_ptr_;
	double time_to_exp_;
};

OptionInfo::OptionInfo(std::unique_ptr<Payoff> payoff, double time_to_exp) :
	payoff_ptr_{std::move(payoff)}, time_to_exp_{time_to_exp} {
}

double OptionInfo::option_payoff(double spot) const
{
	return payoff_ptr_->payoff(spot);
}

double OptionInfo::time_to_expiration() const
{
	return time_to_exp_;
}

void OptionInfo::swap(OptionInfo& rhs) noexcept
{
	using std::swap;
	swap(payoff_ptr_, rhs.payoff_ptr_);
	swap(time_to_exp_, rhs.time_to_exp_);
	//throw std::runtime_error{"Error:..."};	// Compiler warning, runtime error (for demonstration)
}

// Copy Constructor:
OptionInfo::OptionInfo(const OptionInfo& rhs) :
	payoff_ptr_{rhs.payoff_ptr_->clone()},
	time_to_exp_{rhs.time_to_expiration()} {
}

// Copy Assignment:
OptionInfo& OptionInfo::operator =(const OptionInfo& rhs) noexcept
{
	OptionInfo{rhs}.swap(*this);
	return *this;
}
