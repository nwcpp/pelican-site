module;
#include <boost/math/distributions.hpp>
#include <boost/math/distributions/non_central_t.hpp>

export module std_non_central_t_distribution;
import std;

export template<typename T = double>
class std_non_central_t_distribution
{
public:
	// nu = degrees of freedom
	// delta = non-centrality parameter
	std_non_central_t_distribution(T nu, T delta) :nu_{nu}, delta_{delta} {}

	// Functor similar to <random> in the Standard Library:
	T operator()(std::mt19937_64& mt)
	{
		auto unif = ud_(mt);	// Next in pseudorandom unif(0, 1) sequence

		using namespace boost::math;
		boost::math::non_central_t_distribution<T> nctd(nu_, delta_);
		return quantile(nctd, unif);
	}

private:
	T nu_, delta_;
	std::mt19937_64 mt_;
	std::uniform_real_distribution<T> ud_{0.0, 1.0};
};