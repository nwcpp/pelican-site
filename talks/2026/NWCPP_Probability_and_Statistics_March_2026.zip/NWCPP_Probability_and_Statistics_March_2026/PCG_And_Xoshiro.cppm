/*
 * This file is licensed under the Mozilla Public License, v. 2.0.
 * You can obtain a copy of the license at http://mozilla.org/MPL/2.0/.
 */

module;
#include <pcg/pcg_random.hpp>
#include <xoshiro/XoshiroCpp.hpp>

export module PCG_And_Xoshiro;
import std;

export void pcg_example()
{
	using std::cout;
	cout << "\npcg_example(): with chi-squared distribution\n";

	pcg64_fast pcg_rng{42};
	std::chi_squared_distribution<> cs{15};	// 15 dof
	std::vector<double> v;
	v.reserve(20);

	std::ranges::generate_n(std::back_inserter(v), v.capacity(), [&]
		{
			return cs(pcg_rng);
		}
	);

	cout << std::fixed << std::setprecision(4);
	for (auto x : v)
	{
		cout << x << "\n";
	}
	cout << "\n\n";
}

export void xoshiro_example()
{
	using std::cout;
	cout << "\nxoshiro_example(): with binomial distribution\n";

	XoshiroCpp::Xoshiro256PlusPlus xpp_rng{42};

	std::binomial_distribution<> bd{20, 0.45};
	std::vector<double> v;
	v.reserve(bd.t());		// t() = number of Bernoulli trials

	std::ranges::generate_n(std::back_inserter(v), bd.t(), [&] 
		{
			return bd(xpp_rng);
		}
	);

	cout << std::fixed << std::setprecision(0);
	for (auto x : v)
	{
		cout << x << "\n";
	}
	cout << "\n\n";
}
