#pragma once
// Boost doesn't play nicely with modules yet...
#include <boost/math/distributions.hpp>
#include <random>

template<typename T = double> requires std::floating_point<T>
class std_non_central_t_distribution
{
public:
	// nu = degrees of freedom
	// delta = non-centrality parameter
	std_non_central_t_distribution(T nu, T delta) :nu_{nu}, delta_{delta},
		nctd_{nu_, delta_} {}

	// Functor similar to <random> in the Standard Library:
	T operator()(std::mt19937_64& mt)
	{
		auto unif = ud_(mt);	// Next in pseudorandom unif(0, 1) sequence
		return boost::math::quantile(nctd_, unif);
	}

private:
	T nu_, delta_;
	boost::math::non_central_t_distribution<T> nctd_;
	std::uniform_real_distribution<T> ud_{0.0, 1.0};
};