//////////////////////////////////////////////////////////////////////////////
/// 
///  \file      ThreadSafeObject_UnitTest.cpp
///  \brief     Unit testing for ThreadSafeObject.  These tests rely on the
///             boost test framework.
/// 
///  \author    David Brownell (db@davidbrownell.com)
///  \date      09/02/2003 09:05:47 PM
/// 
///  \note
///  
///  \bug
/// 
//////////////////////////////////////////////////////////////////////////////
/// 
///  \attention
///  Copyright (c) 2003 David Brownell.  Permission to use, copy, modify,
///  distribute and sell this software and its documentation for any purpose
///  is hereby granted without fee, provided that both the previous
///  copyright notice and this permission notice appear in all copies and
///  that both the copyright notice and this permission notice appear in
///  supporting documentation.  David Brownell makes no representations
///  about the suitability of this software for any purpose.  It is provided
///  'as is' without express or implied warranty.
/// 
//////////////////////////////////////////////////////////////////////////////
#include <boost/test/auto_unit_test.hpp>
#include <boost/ref.hpp>

#include "ThreadSafeObject.h"

#include <iostream>

//////////////////////////////////////////////////////////////////////////////
///  \struct    EmptyMutex
///  \brief     Just an empty mutex
/// 
struct EmptyMutex {};

//////////////////////////////////////////////////////////////////////////////
///  \struct    EmptyLock
///  \brief     Just an empty lock that does nothing
/// 
struct EmptyLock
{
    template <typename Type>
    static void Lock(Type &) 
    {}

    template <typename Type>
    static void Unlock(Type &)
    {}
};

//////////////////////////////////////////////////////////////////////////////
///  \struct    EmptyTSO
///  \brief     A ThreadSafeObject that works with an EmptyMutex and an EmptyLock.
///             This would never be used in the real world, as it doesn't do 
///             any sort of locking and unlocking.
/// 
template <typename Type, int RetType = ThreadSafeObjectDetails::DEFAULT>
struct EmptyTSO 
{
    typedef ThreadSafeObject<Type, EmptyMutex, EmptyLock, RetType>   type;
};

//////////////////////////////////////////////////////////////////////////////
///  \struct    LockStruct
///  \brief     A lock that can be used to test that Lock and Unlock are being
///             called when expected.
/// 
struct LockStruct
{ 
    static void Lock(int &) { ++iLockCount; }
    static void Unlock(int &) { ++iUnlockCount; }

    static int iLockCount;
    static int iUnlockCount;
};

int LockStruct::iLockCount = 0;
int LockStruct::iUnlockCount = 0;

//////////////////////////////////////////////////////////////////////////////
///  \struct    MyObject
///  \brief     Just a simple object with member variables and methods
/// 
struct MyObject : boost::noncopyable // Ensure that this guy is never copied unintentionally
{ 
    void Foo(void) { std::cout << "MyObject::Foo: " << foo_ << "\n"; }
    void Bar(void) { std::cout << "MyObject::Bar: " << bar_ << "\n"; }

    int         foo_;
    int         bar_;
};

//////////////////////////////////////////////////////////////////////////////
///             ContainerTest
///  \brief     Ensure that the arrow_op types are really what we expect
/// 
void ContainerTest(void)
{
    using namespace ThreadSafeObjectDetails;

    // Fundamental Type
    {
        typedef Container<int, DEFAULT>     Container;
        Container                           c;

        BOOST_TEST((boost::is_same<Container *, typename Container::ThisTraits::type>::value)); 
        BOOST_TEST((boost::is_same<const Container *, typename Container::ThisTraits::const_type>::value));
    }

    // Fundamental Reference
    {
        typedef Container<int &, DEFAULT>   Container;
        int                                 i = 0;
        Container                           c(i);

        BOOST_TEST((boost::is_same<Container *, typename Container::ThisTraits::type>::value));
        BOOST_TEST((boost::is_same<const Container *, typename Container::ThisTraits::const_type>::value));
    }
    
    // Fundamental Pointer
    {
        typedef Container<int *, DEFAULT>   Container;
        Container                           c;

        BOOST_TEST((boost::is_same<Container *, typename Container::ThisTraits::type>::value));
        BOOST_TEST((boost::is_same<const Container *, typename Container::ThisTraits::const_type>::value));
    }

    // Fundamental Pointer Reference    
    {
        typedef Container<int *&, DEFAULT>  Container;
        int *                               ptr = 0;
        Container                           c(ptr);

        BOOST_TEST((boost::is_same<Container *, typename Container::ThisTraits::type>::value));
        BOOST_TEST((boost::is_same<const Container *, typename Container::ThisTraits::const_type>::value));
    }

    // Object Type
    {
        typedef Container<MyObject, DEFAULT>    Container;
        Container                               c;

        BOOST_TEST((boost::is_same<Container *, typename Container::ThisTraits::type>::value));
        BOOST_TEST((boost::is_same<const Container *, typename Container::ThisTraits::const_type>::value));
    }

    // Object Type Reference
    {
        typedef Container<MyObject &, DEFAULT>  Container;
        MyObject                obj;
        obj.foo_ = 1;  // Make the compiler happy

        Container                               c(boost::ref(obj));

        BOOST_TEST((boost::is_same<Container *, typename Container::ThisTraits::type>::value));
        BOOST_TEST((boost::is_same<const Container *, typename Container::ThisTraits::const_type>::value));
    }

    // Object as Pointer
    {
        typedef Container<MyObject, TYPE_POINTER>   Container;
        Container                                   c;

        BOOST_TEST((boost::is_same<MyObject *, typename Container::ThisTraits::type>::value));
        BOOST_TEST((boost::is_same<const MyObject *, typename Container::ThisTraits::const_type>::value));
    }

    // Object as Pointer Reference
    {
        typedef Container<MyObject &, TYPE_POINTER> Container;
        MyObject                obj;
        obj.foo_ = 1;   // Make the compiler happy

        Container                               c(boost::ref(obj));

        BOOST_TEST((boost::is_same<MyObject *, typename Container::ThisTraits::type>::value));
        BOOST_TEST((boost::is_same<const MyObject *, typename Container::ThisTraits::const_type>::value));
    }

    // Object Pointer
    {
        typedef Container<MyObject *, DEFAULT>      Container;
        Container                                   c;

        BOOST_TEST((boost::is_same<MyObject *&, typename Container::ThisTraits::type>::value));
        BOOST_TEST((boost::is_same<const MyObject *&, typename Container::ThisTraits::const_type>::value));
    }

    // Object Pointer Reference
    {
        typedef Container<MyObject *&, DEFAULT>     Container;
        MyObject *                                  ptr = 0;
        Container                                   c(ptr);

        BOOST_TEST((boost::is_same<MyObject *&, typename Container::ThisTraits::type>::value));
        BOOST_TEST((boost::is_same<const MyObject *&, typename Container::ThisTraits::const_type>::value));
    }
}

//////////////////////////////////////////////////////////////////////////////
///             ObjectTest
///  \brief     Ensure that we always have access to the value, and we
///             can use it in expected ways
/// 
void ObjectTest(void)
{
    // Fundamental Type
    {
        EmptyTSO<int>::type         tso;

        tso->value = 1;
        tso.GetLockedContainer()->value = 2;
        tso.GetLockedContainer().Access()->value = 3;
        tso.GetLockedContainer().Access().GetValue()->value = 4;
        
        EmptyTSO<int>::type::LockedContainer    lc;

        lc = tso.GetLockedContainer();
        lc->value = 5;
        ++(lc->value);
        lc->value++;
    }

    // Fundamental Reference
    {
        int                         i = 0;
        EmptyTSO<int &>::type            tso(boost::ref(i));

        tso->value = 1;
        tso.GetLockedContainer()->value = 2;
        tso.GetLockedContainer().Access()->value = 3;
        tso.GetLockedContainer().Access().GetValue()->value = 4;

        EmptyTSO<int &>::type::LockedContainer    lc;

        lc = tso.GetLockedContainer();
        lc->value = 5;
        ++(lc->value);
        lc->value++;

        BOOST_TEST(i == 7);
    }

    // Fundamental Pointer
    {
        int                         i = 0;
        EmptyTSO<int *>::type            tso(&i);

        *(tso->value) = 1;
        *(tso.GetLockedContainer()->value) = 2;
        *(tso.GetLockedContainer().Access()->value) = 3;
        *(tso.GetLockedContainer().Access().GetValue()->value) = 4;

        EmptyTSO<int *>::type::LockedContainer    lc;

        lc = tso.GetLockedContainer();
        *(lc->value) = 5;
        ++(*lc->value);
        (*lc->value)++;

        BOOST_TEST(i == 7);
    }

    // Fundamental Pointer Reference
    {
        int                         i = 0;
        int *                       ptr = &i;
        EmptyTSO<int *&>::type           tso(boost::ref(ptr));

        *(tso->value) = 1;
        *(tso.GetLockedContainer()->value) = 2;
        *(tso.GetLockedContainer().Access()->value) = 3;
        *(tso.GetLockedContainer().Access().GetValue()->value) = 4;

        EmptyTSO<int *&>::type::LockedContainer    lc;

        lc = tso.GetLockedContainer();
        *(lc->value) = 5;
        ++(*lc->value);
        (*lc->value)++;

        BOOST_TEST(i == 7);
    }

    // Object Type
    {
        EmptyTSO<MyObject>::type    tso;

        tso->value.foo_ = 1;
        tso.GetLockedContainer()->value.Foo();
        tso.GetLockedContainer().Access()->value.bar_ = 2;
        tso.GetLockedContainer().Access().GetValue()->value.Bar();

        EmptyTSO<MyObject>::type::LockedContainer   lc;

        lc = tso.GetLockedContainer();
        lc->value.foo_++;

        BOOST_TEST(lc->value.foo_ == 2);
    }

    // Object Reference Type
    {
        MyObject                    obj;
        EmptyTSO<MyObject &>::type       tso(boost::ref(obj));

        tso->value.foo_ = 1;
        tso.GetLockedContainer()->value.Foo();
        tso.GetLockedContainer().Access()->value.bar_ = 2;
        tso.GetLockedContainer().Access().GetValue()->value.Bar();

        EmptyTSO<MyObject &>::type::LockedContainer   lc;

        lc = tso.GetLockedContainer();
        lc->value.foo_++;

        BOOST_TEST(obj.foo_ == 2);
    }

    // Object as Pointer Type
    {
        EmptyTSO<MyObject, ThreadSafeObjectDetails::TYPE_POINTER>::type    tso;

        tso->foo_ = 1;
        tso.GetLockedContainer()->Foo();
        tso.GetLockedContainer().Access()->bar_ = 2;
        tso.GetLockedContainer().Access().GetValue()->Bar();

        EmptyTSO<MyObject, ThreadSafeObjectDetails::TYPE_POINTER>::type::LockedContainer   lc;

        lc = tso.GetLockedContainer();
        lc->foo_++;

        BOOST_TEST(lc->foo_ == 2);
    }

    // Object as Pointer Reference Type
    {
        MyObject                    obj;
        EmptyTSO<MyObject &, ThreadSafeObjectDetails::TYPE_POINTER>::type       tso(boost::ref(obj));

        tso->foo_ = 1;
        tso.GetLockedContainer()->Foo();
        tso.GetLockedContainer().Access()->bar_ = 2;
        tso.GetLockedContainer().Access().GetValue()->Bar();

        EmptyTSO<MyObject &, ThreadSafeObjectDetails::TYPE_POINTER>::type::LockedContainer   lc;

        lc = tso.GetLockedContainer();
        lc->foo_++;

        BOOST_TEST(obj.foo_ == 2);
    }

    // Object Pointer
    {
        MyObject                    obj;
        EmptyTSO<MyObject *>::type       tso(&obj);

        tso->foo_ = 1;
        tso.GetLockedContainer()->Foo();
        tso.GetLockedContainer().Access()->bar_ = 2;
        tso.GetLockedContainer().Access().GetValue()->Bar();

        EmptyTSO<MyObject *>::type::LockedContainer   lc;

        lc = tso.GetLockedContainer();
        lc->foo_++;

        BOOST_TEST(obj.foo_ == 2);
    }

    // Object Pointer Reference
    {
        MyObject                    obj;
        MyObject *                  ptr = &obj;
        EmptyTSO<MyObject *&>::type      tso(boost::ref(ptr));

        tso->foo_ = 1;
        tso.GetLockedContainer()->Foo();
        tso.GetLockedContainer().Access()->bar_ = 2;
        tso.GetLockedContainer().Access().GetValue()->Bar();

        EmptyTSO<MyObject *&>::type::LockedContainer   lc;

        lc = tso.GetLockedContainer();
        lc->foo_++;

        BOOST_TEST(obj.foo_ == 2);
    }
}

//////////////////////////////////////////////////////////////////////////////
///             LockTest
///  \brief     Ensure that the locks are being locked when we think they should
/// 
void LockTest(void)
{
    //---------------------------------------------------------------------------
    typedef ThreadSafeObject<char,  // Any type will do, we are testing the locking
                             int,   // Any type will do, we are testing the locking
                             LockStruct
    > TSO;

    //---------------------------------------------------------------------------
    
    TSO                 tso;

    // In the following tests, the LockedContainer will be created as a temporary,
    // where the lock count is incremented in the dtor and the unlock count is incremented
    // in the dtor
    BOOST_TEST(LockStruct::iLockCount == 0 && LockStruct::iUnlockCount == 0);
    tso->value = 1;
    BOOST_TEST(LockStruct::iLockCount == 1 && LockStruct::iUnlockCount == 1);
    tso.GetLockedContainer()->value = 2;
    BOOST_TEST(LockStruct::iLockCount == 2 && LockStruct::iUnlockCount == 2);
    tso.GetLockedContainer().Access()->value = 3;
    BOOST_TEST(LockStruct::iLockCount == 3 && LockStruct::iUnlockCount == 3);
    tso.GetLockedContainer().Access().GetValue()->value = 4;
    BOOST_TEST(LockStruct::iLockCount == 4 && LockStruct::iUnlockCount == 4);

    // In the following test, we will acquire the lock, hold it, and then release the lock
    BOOST_TEST(LockStruct::iLockCount == LockStruct::iUnlockCount);

    int                         iTempLockCount;

    {
        TSO::LockedContainer        lc;
        
        lc = tso.GetLockedContainer();
        BOOST_TEST(LockStruct::iLockCount != LockStruct::iUnlockCount);
        iTempLockCount = LockStruct::iLockCount;

        lc->value = 2;
        lc->value++;
        ++(lc->value);

        BOOST_TEST(LockStruct::iLockCount != LockStruct::iUnlockCount);
        BOOST_TEST(iTempLockCount == LockStruct::iLockCount);
    }

    BOOST_TEST(LockStruct::iLockCount == LockStruct::iUnlockCount);
}

//---------------------------------------------------------------------------
BOOST_AUTO_UNIT_TEST(UnitTestFunc)
{
    ContainerTest();
    ObjectTest();
    LockTest();
}