//////////////////////////////////////////////////////////////////////////////
/// 
///  \file      coutExample.cpp
///  \brief     Example of using ThreadSafeObject with std::cout
/// 
///  \author    David Brownell (db@davidbrownell.com)
///  \date      09/06/2003 11:24:19 AM
/// 
///  \note
///  
///  \bug
/// 
//////////////////////////////////////////////////////////////////////////////
/// 
///  \attention
///  Copyright (c) 2003 David Brownell.  Permission to use, copy, modify,
///  distribute and sell this software and its documentation for any purpose
///  is hereby granted without fee, provided that both the previous
///  copyright notice and this permission notice appear in all copies and
///  that both the copyright notice and this permission notice appear in
///  supporting documentation.  David Brownell makes no representations
///  about the suitability of this software for any purpose.  It is provided
///  'as is' without express or implied warranty.
/// 
//////////////////////////////////////////////////////////////////////////////
#include "../ThreadSafeObject.h"
#include "Win32.h"

#include <iostream>
#include <boost/ref.hpp>

#if (defined NO_TSO)
    struct Object
    {
        Object(void) : value(std::cout)
        {}

        std::ostream & value;
    };

    Object      g_obj;
    Object *    g_cout = &g_obj;
#else
    ThreadSafeObject<std::ostream &, TSOCriticalSection, TSOCriticalSection>    g_cout(boost::ref(std::cout));
#endif

DWORD WINAPI ThreadProc(void *)
{
    g_cout->value << "One...\n";
    Sleep(rand() % 1000);
    g_cout->value << "Two...\n";
    Sleep(rand() % 1000);
    g_cout->value << "Three...\n";
    Sleep(rand() % 1000);
    g_cout->value << "Four!\n";

    return(0);
}

int main(void)
{
    srand(GetTickCount());
    LaunchThreads(60, ThreadProc);
    return(0);
}