//////////////////////////////////////////////////////////////////////////////
/// 
///  \file      Win32.h
///  \brief     Some small utility functions and objects that will help
///             when running the ThreadSafeObject examples in a Win32 
///             environment.
/// 
///  \author    David Brownell (db@davidbrownell.com)
///  \date      09/06/2003 11:00:05 AM
/// 
///  \note
///  
///  \bug
/// 
//////////////////////////////////////////////////////////////////////////////
/// 
///  \attention
///  Copyright (c) 2003 David Brownell.  Permission to use, copy, modify,
///  distribute and sell this software and its documentation for any purpose
///  is hereby granted without fee, provided that both the previous
///  copyright notice and this permission notice appear in all copies and
///  that both the copyright notice and this permission notice appear in
///  supporting documentation.  David Brownell makes no representations
///  about the suitability of this software for any purpose.  It is provided
///  'as is' without express or implied warranty.
/// 
//////////////////////////////////////////////////////////////////////////////
#ifndef DB_INCLUDE_GUARD_87A6B44921EF462F8717689EC966BB68
#define DB_INCLUDE_GUARD_87A6B44921EF462F8717689EC966BB68
///////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <boost/scoped_array.hpp>

//////////////////////////////////////////////////////////////////////////////
///  \struct    TSOCriticalSection
///  \brief     Severs as both a mutex type and locking type that
///             ban be used with ThreadSafeObject
/// 
struct TSOCriticalSection
{
    TSOCriticalSection(void)
    { InitializeCriticalSection(&cs); }

    ~TSOCriticalSection(void)
    { DeleteCriticalSection(&cs); }

    static inline void Lock(TSOCriticalSection &c)
    { EnterCriticalSection(&c.cs); }

    static inline void Unlock(TSOCriticalSection &c)
    { LeaveCriticalSection(&c.cs); }

private:
    CRITICAL_SECTION        cs;
};

//////////////////////////////////////////////////////////////////////////////
///             LaunchThreads
///  \brief     Launches N threads and waits for them to complete
/// 
static bool LaunchThreads(unsigned long ulNumThreads, DWORD (WINAPI *tProc)(void *), void *pParam = 0)
{
    boost::scoped_array<HANDLE>         pHandles(new HANDLE[ulNumThreads]);

    HANDLE *                ptr;
    unsigned long           ulThreadID;
    unsigned long           ulThreadsRemaining;

    ptr = pHandles.get();
    ulThreadsRemaining = ulNumThreads;

    while(ulThreadsRemaining--)
        *ptr++ = CreateThread(0, 0, 
                              tProc,
                              pParam,
                              0, 
                              &ulThreadID);

    unsigned long           ulRetVal;
    
    ulRetVal = WaitForMultipleObjects(ulNumThreads, pHandles.get(), TRUE, INFINITE);
    ASSERT(ulRetVal != WAIT_FAILED);

    // Close the handles
    ptr = pHandles.get();
    ulThreadsRemaining = ulNumThreads;

    while(ulThreadsRemaining--)
        CloseHandle(*ptr++);

    return(true);
}

///////////////////////////////////////////////////////////////////////////
#endif //DB_INCLUDE_GUARD_87A6B44921EF462F8717689EC966BB68
