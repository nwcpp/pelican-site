//////////////////////////////////////////////////////////////////////////////
/// 
///  \file      ReferenceCountExample.cpp
///  \brief     An example using ThreadSafeObject with a reference counted
///             object
/// 
///  \author    David Brownell (db@davidbrownell.com)
///  \date      09/06/2003 10:56:54 AM
/// 
///  \note
///  
///  \bug
/// 
//////////////////////////////////////////////////////////////////////////////
/// 
///  \attention
///  Copyright (c) 2003 David Brownell.  Permission to use, copy, modify,
///  distribute and sell this software and its documentation for any purpose
///  is hereby granted without fee, provided that both the previous
///  copyright notice and this permission notice appear in all copies and
///  that both the copyright notice and this permission notice appear in
///  supporting documentation.  David Brownell makes no representations
///  about the suitability of this software for any purpose.  It is provided
///  'as is' without express or implied warranty.
/// 
//////////////////////////////////////////////////////////////////////////////
#include "../ThreadSafeObject.h"
#include "Win32.h"

struct MyObject
{
    MyObject(void) : cRefCount_(0)
    {}

    unsigned long AddRef(void)
    {
        unsigned long ulRetVal = ++(cRefCount_->value);
        return(ulRetVal);
    }

    unsigned long Release(void)
    {
        unsigned long ulRetVal = --(cRefCount_->value);

        if(ulRetVal == 0)
            OutputDebugString("Time to delete");

        return(ulRetVal);
    }

private:
    ThreadSafeObject<unsigned long, TSOCriticalSection, TSOCriticalSection>     cRefCount_;
} g_myObject;

DWORD WINAPI ThreadProc(void *)
{
    OutputDebugString("AddRef");
    g_myObject.AddRef();

    // Simulate stuff happening
    Sleep(1000);

    OutputDebugString("Release");
    g_myObject.Release();

    return(0);
}

int main(void)
{
    LaunchThreads(10, ThreadProc);
    return(0);
}