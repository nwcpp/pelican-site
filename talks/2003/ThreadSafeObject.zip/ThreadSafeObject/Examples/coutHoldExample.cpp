//////////////////////////////////////////////////////////////////////////////
/// 
///  \file      coutHoldExample.cpp
///  \brief     This example is similar to coutExample.cpp, but rather
///             than acquiring the lock each time g_cout is used, the lock
///             is acquired only once.
/// 
///  \author    David Brownell (db@davidbrownell.com)
///  \date      09/06/2003 11:24:19 AM
/// 
///  \note
///  
///  \bug
/// 
//////////////////////////////////////////////////////////////////////////////
/// 
///  \attention
///  Copyright (c) 2003 David Brownell.  Permission to use, copy, modify,
///  distribute and sell this software and its documentation for any purpose
///  is hereby granted without fee, provided that both the previous
///  copyright notice and this permission notice appear in all copies and
///  that both the copyright notice and this permission notice appear in
///  supporting documentation.  David Brownell makes no representations
///  about the suitability of this software for any purpose.  It is provided
///  'as is' without express or implied warranty.
/// 
//////////////////////////////////////////////////////////////////////////////
#include "../ThreadSafeObject.h"
#include "Win32.h"

#include <iostream>
#include <boost/ref.hpp>

typedef ThreadSafeObject<std::ostream &, TSOCriticalSection, TSOCriticalSection> TSO;

TSO g_cout(boost::ref(std::cout));


DWORD WINAPI ThreadProc(void *)
{
    TSO::LockedContainer        lc;

    lc = g_cout.GetLockedContainer();

    lc->value << "One...\n";
    Sleep(rand() % 1000);
    lc->value << "Two...\n";
    Sleep(rand() % 1000);
    lc->value << "Three...\n";
    Sleep(rand() % 1000);
    lc->value << "Four!\n";

    return(0);
}

int main(void)
{
    srand(GetTickCount());
    LaunchThreads(5, ThreadProc);
    return(0);
}