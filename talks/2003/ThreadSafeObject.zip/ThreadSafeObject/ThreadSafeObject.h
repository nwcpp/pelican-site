//////////////////////////////////////////////////////////////////////////////
/// 
///  \file      ThreadSafeObject.h
///  \brief     Contains the ThreadSafeObject object, an object that automagicly
///             enables thread-safe access to a specific variable.
/// 
///  \author    David Brownell (db@davidbrownell.com)
///  \date      09/01/2003 09:23:30 PM
/// 
///  \note
///  
///  \bug
/// 
//////////////////////////////////////////////////////////////////////////////
/// 
///  \attention
///  Copyright (c) 2003 David Brownell.  Permission to use, copy, modify,
///  distribute and sell this software and its documentation for any purpose
///  is hereby granted without fee, provided that both the previous
///  copyright notice and this permission notice appear in all copies and
///  that both the copyright notice and this permission notice appear in
///  supporting documentation.  David Brownell makes no representations
///  about the suitability of this software for any purpose.  It is provided
///  'as is' without express or implied warranty.
/// 
//////////////////////////////////////////////////////////////////////////////
#ifndef DB_INCLUDE_GUARD_BC46A8DF87A1455199EB8DBF3FF65AD5
#define DB_INCLUDE_GUARD_BC46A8DF87A1455199EB8DBF3FF65AD5
///////////////////////////////////////////////////////////////////////////

#include <cassert>

#include <boost/utility.hpp>
#include <boost/type_traits.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/int.hpp>

#if (!defined ASSERT)
#   define ASSERT assert
#endif

//////////////////////////////////////////////////////////////////////////////
///             ThreadSafeObjectDetails
///  \brief     Contains objects and functions specific to the ThreadSafeObject
///             implementation.
/// 
namespace ThreadSafeObjectDetails
{
    //////////////////////////////////////////////////////////////////////////////
    ///             ReturnType
    ///  \brief     Defines the different types that may be returned
    ///             from a Container.  The is the same as the types returned
    ///             from a -> operator.
    ///
    enum ReturnType 
    { 
        DEFAULT = 0,                // Selects the most appropriate return type based on Type
        CONTAINER_POINTER,          // The return value of -> is Container<Type> *
        TYPE,                       // The return value of -> is Type &
        TYPE_POINTER                // The return value of -> is Type *
    };

    //---------------------------------------------------------------------------
    //  Turn the enums defined above into actual types
    typedef boost::mpl::int_<DEFAULT>               DefaultType;
    typedef boost::mpl::int_<CONTAINER_POINTER>     ContainerPointerType;
    typedef boost::mpl::int_<TYPE>                  TypeType;
    typedef boost::mpl::int_<TYPE_POINTER>          TypePointerType;

    //////////////////////////////////////////////////////////////////////////////
    ///  \struct    Type2ReturnTypeImpl
    ///  \brief     The inner-workings of Type2ReturnType.  Will compute the
    ///             most appropriate ReturnType for Type by looking at the 
    ///             properties of the type.  For example, is it a fundamental
    ///             type, a class, a pointer, or a pointer to a class.
    /// 
    template <typename Type>
    struct Type2ReturnTypeImpl
    {
        typedef typename boost::remove_reference<Type>::type        no_ref_;
        typedef typename boost::remove_pointer<no_ref_>::type       no_pointer_;

        typedef typename boost::mpl::if_c<boost::is_fundamental<no_ref_>::value,
                                          ContainerPointerType,
                                          typename boost::mpl::if_c<boost::is_class<no_ref_>::value,
                                                                    ContainerPointerType,
                                                                    typename boost::mpl::if_c<boost::is_pointer<no_ref_>::value,
                                                                                              typename boost::mpl::if_c<boost::is_class<no_pointer_>::value,
                                                                                                                        TypeType,
                                                                                                                        ContainerPointerType>::type,
                                                                                              void>::type
                                                                    >::type
                                          >::type
        type;
    };
    
    //////////////////////////////////////////////////////////////////////////////
    ///  \struct    Type2ReturnType
    ///  \brief     Given a type, will compute the optimal return type if
    ///             RetType is DEFAULT, otherwise will set the type to RetType
    /// 
    template <typename Type, int RetType>
    struct Type2ReturnType
    {
        typedef typename boost::mpl::if_c<boost::is_same<boost::mpl::int_<RetType>, DefaultType>::value,
                                          typename Type2ReturnTypeImpl<Type>::type,
                                          boost::mpl::int_<RetType>
        >::type type;
    };

    ///////////////////////////////////////////////////////////////////////////////
    ///  \class     Container
    ///  \brief     Ensures that the arrow operator is defined in a meaningful
    ///             way for the specific type
    ///
    template <typename Type, int RetType>
    class Container 
    {
    public:
        //---------------------------------------------------------------------------
        // 
        //  Public Types
        // 
        //---------------------------------------------------------------------------
        
        //////////////////////////////////////////////////////////////////////////////
        ///  \struct    traits
        ///  \brief     Will define types and methods suitable to return the 
        ///             values corresponding to the given RetType
        /// 
        template <typename RetType> 
        struct traits {};

        template <> struct traits<ContainerPointerType>
        {
            typedef Container *             type;
            typedef const Container *       const_type;

            static inline type Access(Container &c) { return(&c); }
            static inline const_type Access(const Container &c) { return(&c); }
        };
        
        template <> struct traits<TypeType>
        {
            typedef typename boost::add_reference<Type>::type                                       type;
            
            typedef typename boost::remove_reference<Type>::type                                    no_ref_;
            typedef typename boost::mpl::if_c<boost::is_pointer<no_ref_>::value,
                                              typename boost::add_pointer<typename boost::add_const<typename boost::remove_pointer<no_ref_>::type>::type>::type,
                                              typename boost::add_const<no_ref_>::type>::type       const_no_ref_;

            typedef typename boost::add_reference<const_no_ref_>::type                              const_type;

            static inline type Access(Container &c) { return(c.value); }
            static inline const_type Access(const Container &c) { return(c.value); }
        };

        template <> struct traits<TypePointerType>
        {
            typedef typename boost::remove_reference<Type>::type                                    no_ref_;
            typedef typename boost::add_const<no_ref_>::type                                        const_no_ref_;

            typedef typename boost::add_pointer<no_ref_>::type                                      type;
            typedef typename boost::add_pointer<const_no_ref_>::type                                const_type;

            static inline type Access(Container &c) { return(&c.value); }
            static inline const_type Access(const Container &c) { return(&c.value); }
        };

        ///////////////////////////////////////////////////////////////////////////////
        ///             ThisReturnType
        ///  \brief     The ReturnType that best describes the Type passed as 
        ///             a template argument to Container.
        ///
        typedef typename Type2ReturnType<Type, RetType>::type       ThisReturnType;

        ///////////////////////////////////////////////////////////////////////////////
        ///             ThisTraits
        ///  \brief     The traits associated with the type category that is
        ///             associated with the type passed to Container
        ///
        typedef traits<ThisReturnType>                              ThisTraits;

        //---------------------------------------------------------------------------
        // 
        //  Public Methods
        // 
        //---------------------------------------------------------------------------
        Container(void) {}
        template <typename Arg1> Container(Arg1 arg1) : value(arg1) {}
        template <typename Arg1, typename Arg2> Container(Arg1 arg1, Arg2 arg2) : value(arg1, arg2) {}
        template <typename Arg1, typename Arg2, typename Arg3> Container(Arg1 arg1, Arg2 arg2, Arg3 arg3) : value(arg1, arg2, arg3) {}
        template <typename Arg1, typename Arg2, typename Arg3, typename Arg4> Container(Arg1 arg1, Arg2 arg2, Arg3 arg3, Arg4 arg4) : value(arg1, arg2, arg3, arg4) {}
        template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5> Container(Arg1 arg1, Arg2 arg2, Arg3 arg3, Arg4 arg4, Arg5 arg5) : value(arg1, arg2, arg3, arg4, arg5) {}
        template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, typename Arg6> Container(Arg1 arg1, Arg2 arg2, Arg3 arg3, Arg4 arg4, Arg5 arg5, Arg6 arg6) : value(arg1, arg2, arg3, arg4, arg5, arg6) {}

        inline typename ThisTraits::type GetValue(void)
        { return(ThisTraits::Access(*this)); }

        inline typename ThisTraits::const_type GetValue(void) const
        { return(ThisTraits::Access(*this)); }

        inline typename ThisTraits::type operator->(void)
        { return(GetValue()); }

        inline typename ThisTraits::const_type operator->(void) const
        { return(GetValue()); }

        //---------------------------------------------------------------------------
        // 
        //  Public Data
        // 
        //---------------------------------------------------------------------------
        Type        value;
    };

    //////////////////////////////////////////////////////////////////////////////
    ///  \class     LockedContainer
    ///  \brief     An object that contains a reference to Type while ensuring that
    ///             the contained mutex is in a locked state throughout its lifetime.
    ///             This object to call LockPolicy::Lock on its ctor and 
    ///             LockPolicy::Unlock on its dtor.  To enable copying, 
    ///             LockedContainer behaves similar to std::auto_ptr in that
    ///             it has transfer of ownership copy semantics.
    /// 
    template <typename Type, typename MutexType, typename LockPolicy, int RetType>
    class LockedContainer
    {
        struct LockedContainerRef
        { 
            LockedContainerRef(LockedContainer &rhs) : ref(rhs) {}
            LockedContainer & ref;
        };

    public:
        //---------------------------------------------------------------------------
        // 
        //  Public Types
        // 
        //---------------------------------------------------------------------------
        typedef Container<Type, RetType>        Container;

        //---------------------------------------------------------------------------
        // 
        //  Public Methods
        // 
        //---------------------------------------------------------------------------
        LockedContainer(void)
        {
            pCont_      = 0;
            pMutex_     = 0;
        }

        LockedContainer(Container &c, MutexType &mutex)
        {
            pCont_      = &c;
            pMutex_     = &mutex;

            LockPolicy::Lock(*pMutex_);
        }

        LockedContainer(LockedContainer &rhs)
        {
            pCont_      = 0;
            pMutex_     = 0;

            *this = rhs;
        }

        LockedContainer(LockedContainerRef rhs)
        {
            pCont_      = 0;
            pMutex_     = 0;

            *this = rhs;
        }

        ~LockedContainer(void)
        {
            reset();
        }

        inline operator LockedContainerRef(void)
        { return(LockedContainerRef(*this)); }

        inline LockedContainer & operator =(LockedContainer &rhs)
        { return(AssignImpl(rhs)); }

        inline LockedContainer & operator =(LockedContainerRef &rhs)
        { return(AssignImpl(rhs.ref)); }

        inline Container & Access(void)
        {
            ASSERT(pCont_);
            return(*pCont_);
        }

        inline const Container & Access(void) const
        {
            ASSERT(pCont_);
            return(*pCont_);
        }

        inline Container & operator->(void)
        { return(Access()); }

        inline const Container & operator->(void) const
        { return(Access()); }

        void reset(void)
        { 
            if(pCont_)
            {
                ASSERT(pMutex_);
                LockPolicy::Unlock(*pMutex_);
            }

            pCont_  = 0;
            pMutex_ = 0;
        }

    private:
        //---------------------------------------------------------------------------
        // 
        //  Private Data
        // 
        //---------------------------------------------------------------------------
        Container *             pCont_;
        MutexType *             pMutex_;

        //---------------------------------------------------------------------------
        // 
        //  Private Methods
        // 
        //---------------------------------------------------------------------------
        LockedContainer & AssignImpl(LockedContainer &rhs)
        {
            reset();

            pCont_      = rhs.pCont_;
            pMutex_     = rhs.pMutex_;

            rhs.pCont_ = 0;
            return(*this);
        }
    };
}

///////////////////////////////////////////////////////////////////////////////
///  \class     ThreadSafeObject
///  \brief     Contains an object whose access is protected by a mutex concept.
///             ThreadSafeObject eases the pain of working with synchronized
///             objects by automating the locking/unlocking process.
///
template <
            typename Type, 
            typename MutexType, 
            typename LockPolicy, 
            int RetType = ThreadSafeObjectDetails::DEFAULT
>
class ThreadSafeObject
{
public:
    //---------------------------------------------------------------------------
    // 
    //  Public Types
    // 
    //---------------------------------------------------------------------------
    typedef Type                                                                                value_type;
    typedef MutexType                                                                           Mutex;
    typedef ThreadSafeObjectDetails::LockedContainer<value_type, Mutex, LockPolicy, RetType>    LockedContainer;

    //---------------------------------------------------------------------------
    // 
    //  Public Methods
    // 
    //---------------------------------------------------------------------------
    ThreadSafeObject(void) {}
    template <typename Arg1> ThreadSafeObject(Arg1 arg1) : object_(arg1) {}
    template <typename Arg1, typename Arg2> ThreadSafeObject(Arg1 arg1, Arg2 arg2) : object_(arg1, arg2) {}
    template <typename Arg1, typename Arg2, typename Arg3> ThreadSafeObject(Arg1 arg1, Arg2 arg2, Arg3 arg3) : object_(arg1, arg2, arg3) {}
    template <typename Arg1, typename Arg2, typename Arg3, typename Arg4> ThreadSafeObject(Arg1 arg1, Arg2 arg2, Arg3 arg3, Arg4 arg4) : object_(arg1, arg2, arg3, arg4) {}
    template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5> ThreadSafeObject(Arg1 arg1, Arg2 arg2, Arg3 arg3, Arg4 arg4, Arg5 arg5) : object_(arg1, arg2, arg3, arg4, arg5) {}
    template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, typename Arg6> ThreadSafeObject(Arg1 arg1, Arg2 arg2, Arg3 arg3, Arg4 arg4, Arg5 arg5, Arg6 arg6) : object_(arg1, arg2, arg3, arg4, arg5, arg6) {}

    inline LockedContainer GetLockedContainer(void)
    { return(LockedContainer(object_, mutex_)); }

    inline LockedContainer GetLockedContainer(void) const
    { return(LockedContainer(object_, mutex_)); }

    inline LockedContainer operator->(void)
    { return(GetLockedContainer()); }

    inline LockedContainer operator->(void) const
    { return(GetLockedContainer()); }

private:
    //---------------------------------------------------------------------------
    // 
    //  Private Data
    // 
    //---------------------------------------------------------------------------
    mutable ThreadSafeObjectDetails::Container<Type, RetType>   object_;
    mutable Mutex                                               mutex_;
};

///////////////////////////////////////////////////////////////////////////
#endif //DB_INCLUDE_GUARD_BC46A8DF87A1455199EB8DBF3FF65AD5
