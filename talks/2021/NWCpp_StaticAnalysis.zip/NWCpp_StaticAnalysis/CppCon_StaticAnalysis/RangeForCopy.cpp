#define DEMO_RangeForCopy 1
#if DEMO_RangeForCopy

#include <vector>

struct LargeStruct
{
    int data[42] = { 42 };
};

struct SmallStruct
{
    int data = 3;
};

void takeInt(int);
void takeIntMut(int&);

void foo(const std::vector<LargeStruct>& largeV, const std::vector<SmallStruct>& smallV)
{
    // Without mutation
    for (auto elem : largeV)
        takeInt(elem.data[0]);

    // Small struct
    for (auto elem : smallV)
        takeInt(elem.data);

    // With mutation
    for (auto elem : largeV)
        elem.data[0] = 43;

    for (auto elem : largeV)
        takeIntMut(elem.data[0]);
}
#endif