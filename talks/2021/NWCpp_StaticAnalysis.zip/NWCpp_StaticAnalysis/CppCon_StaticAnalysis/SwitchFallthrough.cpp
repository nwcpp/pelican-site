#define DEMO_Fallthrough 1
#if DEMO_Fallthrough

void doSomething();
void doSomethingForCond();
void doSomethingElse();

void foo(int a, bool cond)
{
    switch (a)
    {
    case 0:
        doSomething();
        [[fallthrough]];
    case 1:
        if (cond) {
            doSomethingForCond();
        }
        else
            [[fallthrough]];
    case 2:
    case 3:
        doSomethingElse();
        break;
    default:
        break;
    }
}
#endif