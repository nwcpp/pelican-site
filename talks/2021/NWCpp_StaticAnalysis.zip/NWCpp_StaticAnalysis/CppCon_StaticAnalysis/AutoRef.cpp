#define DEMO_AutoRef 1
#if DEMO_AutoRef

#include <vector>

struct LargeStruct
{
    int data[42] = { 42 };
};

class SomeStruct
{
    LargeStruct largeStruct;
public:
    const LargeStruct& GetLargeStruct() const noexcept {
        return largeStruct;
    }
};

void foo(const SomeStruct& s) noexcept
{
    // Immutable. Unnecessary copy.
    const auto large_struct = s.GetLargeStruct();

    // Mutable. We need to copy.
    auto large_struct_mut = s.GetLargeStruct();
    large_struct_mut.data[0] = 43;
    
    // Lifetimes not extended past end of statement. We need to copy.
    const auto large_struct_from_temp = SomeStruct().GetLargeStruct();
}

#endif