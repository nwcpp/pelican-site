#define DEMO_MissingDefault 1
#if DEMO_MissingDefault

void doSomething();
void doSomethingElse();

void foo(int a)
{
    switch(a)
    {
    case 0:
        doSomething();
        break;
    case 1:
        doSomethingElse();
        break;
    }
}

#endif