﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Ccr.Core;
using System.IO;
using Microsoft.Ccr.Adapters.IO;
using System.Diagnostics;

namespace AsyncProgrammingWithCcr
{
    class Program
    {
        static int blocksize = 128 * 1024;

        #region run demo
        static void Main(string[] args)
        {
            var data = new byte[1024 * 1024 * 128];
            new Random().NextBytes(data);

            // Note: CopyStream2 is for illustrative purposes only. On most streams reading/writing is
            // I/O-bound and CPU-bound. Thus, parallelizing reads and writes will add no advantage.

            MemoryStream m1 = new MemoryStream(data);
            MemoryStream m2 = new MemoryStream();

            var dispatcher = new Dispatcher();
            var queue = new DispatcherQueue("myqueue", dispatcher);

            queue.Enqueue(new IterativeTask<Stream, Stream>(m1, m2, CopyStream2));

            Console.ReadLine();
        }
        #endregion

        #region CopyStream (sequential async read/write)
        static IEnumerator<ITask> CopyStream(Stream source, Stream dest)
        {
            try
            {
                var buffer = new byte[blocksize];
                int read = 0;
                do
                {
                    var readResult = StreamAdapter.Read(source, buffer, 0, buffer.Length);
                    yield return (Choice)readResult;

                    var exception = (Exception)readResult;
                    if (exception == null)
                    {
                        read = (int)readResult;
                        if (read > 0)
                        {
                            var writeResult = StreamAdapter.Write(dest, buffer, 0, read);
                            yield return (Choice)writeResult;
                            exception = (Exception)writeResult;
                        }
                    }

                    if (exception != null)
                    {
                        // handle error
                        yield break;
                    }

                } while (read > 0);
            }
            finally
            {
                Console.WriteLine("Done.");
                source.Close();
                dest.Close();
            }
        }
        #endregion

        #region CopyStream II (concurrent async read/write)
        static IEnumerator<ITask> CopyStream2(Stream source, Stream dest)
        {
            try
            {
                var bufferA = new byte[blocksize];
                var bufferB = new byte[blocksize];

                int read = 0;
                int write = 0;

                var readResult = StreamAdapter.Read(source, bufferB, 0, bufferB.Length);
                yield return (Choice)readResult;

                var exception = (Exception)readResult;
                if (exception != null)
                {
                    // handle error
                    yield break;
                }

                read = (int)readResult;
                write = read;

                while (write > 0)
                {
                    var writeResult = StreamAdapter.Write(dest, bufferB, 0, write);
                    if (read > 0)
                    {
                        // read new bytes and write existing buffer
                        readResult = StreamAdapter.Read(source, bufferA, 0, bufferA.Length);

                        yield return Arbiter.Choice(
                            Arbiter.JoinedReceive<int, EmptyValue>(false, readResult, writeResult,
                                (r, s) => { read = r; }
                            ),
                            Arbiter.Receive<Exception>(false, readResult, e => { exception = e; }),
                            Arbiter.Receive<Exception>(false, writeResult, e => { exception = e; })
                        );

                        write = read;

                        var temp = bufferA;
                        bufferA = bufferB;
                        bufferB = temp;
                    }
                    else
                    {
                        // write remaining bytes
                        yield return (Choice)writeResult;
                        exception = (Exception)writeResult;
                    }

                    if (exception != null)
                    {
                        // handle error
                        yield break;
                    }
                }
            }
            finally
            {
                Console.WriteLine("Done.");
                source.Close();
                dest.Close();
            }
        }
        #endregion
    }
}
