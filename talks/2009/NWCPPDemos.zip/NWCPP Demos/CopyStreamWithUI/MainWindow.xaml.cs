﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.IO;

using ccr = Microsoft.Ccr.Core;
using ccrwpf = Microsoft.Ccr.Adapters.Wpf;

namespace CopyStreamWithUI
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ccrwpf.WpfServicePort _ccrAdapter;
        ccr.DispatcherQueue _queue;
        ccr.Dispatcher _dispatcher;

        CopyFileService _copier;
        
        public MainWindow()
        {
            InitializeComponent();

            // create application logic worker
            _dispatcher = new ccr.Dispatcher();
            _queue = new ccr.DispatcherQueue("worker", _dispatcher);
            _copier = new CopyFileService(_queue);

            // create adapter 
            var adapterDispatcher = new ccr.Dispatcher(1, "adapter");
            var adapterQueue = new ccr.DispatcherQueue("adapter", adapterDispatcher);
            _ccrAdapter = ccrwpf.WpfAdapter.Create(adapterQueue);

            // make sure to dispose dispatcher on exit
            Closed += (s, e) =>
                {
                    adapterDispatcher.Dispose();
                    _dispatcher.Dispose();
                };
        }

        private void CopyFile_Click(object sender, RoutedEventArgs e)
        {
            string[] files;
            if (!GetSourceFile(out files))
            {
                return;
            }

            string destination;
            if (!GetDestinationDirectory(out destination))
            {
                return;
            }

            foreach (var file in files)
            {
                var status = new CopyStatus(_queue, _ccrAdapter) { Filename = System.IO.Path.GetFileName(file) };

                CopyStatus.AllTransfers.Add(status);

                var name = System.IO.Path.GetFileName(file);
                var target = System.IO.Path.Combine(destination, name);

                _copier.CopyFile(file, target, status.UpdatePort);
            }
        }

        private bool GetDestinationDirectory(out string destination)
        {
            destination = null;

            var fd = new System.Windows.Forms.FolderBrowserDialog { Description = "Select a destination folder." };

            var result = fd.ShowDialog();
            if (result != System.Windows.Forms.DialogResult.OK)
            {
                return false;
            }
            destination = fd.SelectedPath;
            return true;
        }

        private bool GetSourceFile(out string[] files)
        {
            files = null;
            var ofd = new System.Windows.Forms.OpenFileDialog { Multiselect = true };

            #region sanity checks
            var result = ofd.ShowDialog();
            if (result != System.Windows.Forms.DialogResult.OK)
            {
                return false;
            }

            if (ofd.FileNames == null || ofd.FileNames.Length == 0)
            {
                return false;
            }
            #endregion

            files = ofd.FileNames;
            return true;
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            CopyStatus.AllTransfers.Clear();
        }
    }

    /// <summary>
    /// Track the transfer status in the user interface.
    /// DependencyObject have thread affinity. They can only be used from the 
    /// user interface thread.
    /// </summary>
    public class CopyStatus : DependencyObject
    {
        /// <summary>
        /// The list of all ongoing file copies
        /// </summary>
        public static ObservableCollection<CopyStatus> AllTransfers
        {
            get { return _allTransfers; }
        }

        public string Filename
        {
            get { return (string)GetValue(FilenameProperty); }
            set { SetValue(FilenameProperty, value); }
        }

        public bool IsComplete
        {
            get { return (bool)GetValue(IsCompleteProperty); }
            set { SetValue(IsCompleteProperty, value); }
        }

        public bool HasError
        {
            get { return (bool)GetValue(HasErrorProperty); }
            set { SetValue(HasErrorProperty, value); }
        }

        public double Progress
        {
            get { return (double)GetValue(ProgressProperty); }
            set { SetValue(ProgressProperty, value); }
        }

        #region status update through CCR adapter
        public ccr.PortSet<double, ccr.SuccessResult, Exception> UpdatePort
        {
            get { return _updatePort; }
        }

        public CopyStatus(ccr.DispatcherQueue queue, ccrwpf.WpfServicePort adapter)
        {
            _adapter = adapter;
            ccr.Arbiter.Activate(
                queue,
                new ccr.Interleave(
                    new ccr.TeardownReceiverGroup(
                        ccr.Arbiter.Receive<ccr.SuccessResult>(false, _updatePort, CopyCompleted),
                        ccr.Arbiter.Receive<Exception>(false, _updatePort, CopyFailed)
                    ),
                    new ccr.ExclusiveReceiverGroup(
                        ccr.Arbiter.Receive<double>(true, _updatePort, SetProgress)
                    ),
                    new ccr.ConcurrentReceiverGroup()
               )
            );
        }

        private void SetProgress(double value)
        {
            _adapter.Invoke(() => Progress = value);
        }

        private void CopyCompleted(ccr.SuccessResult success)
        {
            _adapter.Invoke(() => IsComplete = true);
        }

        private void CopyFailed(Exception exception)
        {
            _adapter.Invoke(() => HasError = true);
        }
        #endregion

        #region dependency property declarations
        // Using a DependencyProperty as the backing store for Progress.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ProgressProperty =
            DependencyProperty.Register("Progress", typeof(double), typeof(CopyStatus), new UIPropertyMetadata(0.0));

        // Using a DependencyProperty as the backing store for IsComplete.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsCompleteProperty =
            DependencyProperty.Register("IsComplete", typeof(bool), typeof(CopyStatus), new UIPropertyMetadata(false));

        // Using a DependencyProperty as the backing store for Filename.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FilenameProperty =
            DependencyProperty.Register("Filename", typeof(string), typeof(CopyStatus));

        // Using a DependencyProperty as the backing store for HasError.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HasErrorProperty =
            DependencyProperty.Register("HasError", typeof(bool), typeof(CopyStatus), new UIPropertyMetadata(false));

        #endregion

        #region private fields
        static ObservableCollection<CopyStatus> _allTransfers = new ObservableCollection<CopyStatus>();

        private ccr.PortSet<double, ccr.SuccessResult, Exception> _updatePort = new ccr.PortSet<double, ccr.SuccessResult, Exception>();

        ccrwpf.WpfServicePort _adapter; 
        #endregion
    }
}
