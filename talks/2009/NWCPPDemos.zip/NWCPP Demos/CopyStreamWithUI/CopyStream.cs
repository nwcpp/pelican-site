﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ccr.Core;
using Microsoft.Ccr.Adapters.IO;
using System.IO;

namespace CopyStreamWithUI
{
    class CopyStreamHelper
    {
        internal const int BlockSize = 512 * 1024;

        public static IEnumerator<ITask> CopyStream(Stream source, Stream dest, PortSet<double, SuccessResult, Exception> progress)
        {
            try
            {
                var buffer = new byte[BlockSize];
                int read = 0;
                int total = 0;

                var length = source.Length;

                progress.Post(0.0);

                do
                {
                    progress.Post((double)total / (double)length);

                    var readResult = StreamAdapter.Read(source, buffer, 0, buffer.Length);
                    yield return (Choice)readResult;

                    var exception = (Exception)readResult;
                    if (exception == null)
                    {
                        read = (int)readResult;
                        total += read;

                        if (read > 0)
                        {
                            var writeResult = StreamAdapter.Write(dest, buffer, 0, read);
                            yield return (Choice)writeResult;
                            exception = (Exception)writeResult;
                        }
                    }

                    if (exception != null)
                    {
                        progress.Post(exception);
                        yield break;
                    }
                } while (read > 0);
            }
            finally
            {
                progress.Post(SuccessResult.Instance);
                source.Close();
                dest.Close();
            }
        }

        public static IEnumerator<ITask> CopyStream2(Stream source, Stream dest, PortSet<double, SuccessResult, Exception> progress)
        {
            try
            {
                var bufferA = new byte[BlockSize];
                var bufferB = new byte[BlockSize];

                int read = 0;
                int write = 0;
                int total = 0;
                long length = source.Length;

                var readResult = StreamAdapter.Read(source, bufferB, 0, bufferB.Length);
                yield return (Choice)readResult;

                var exception = (Exception)readResult;
                if (exception != null)
                {
                    // handle error
                    yield break;
                }

                read = (int)readResult;
                write = read;
                

                while (write > 0)
                {
                    progress.Post((double)total / (double)length);

                    var writeResult = StreamAdapter.Write(dest, bufferB, 0, write);
                    if (read > 0)
                    {
                        // read new bytes and write existing buffer
                        readResult = StreamAdapter.Read(source, bufferA, 0, bufferA.Length);

                        yield return Arbiter.Choice(
                            Arbiter.JoinedReceive<int, EmptyValue>(false, readResult, writeResult,
                                (r, s) => { read = r; }
                            ),
                            Arbiter.Receive<Exception>(false, readResult, e => { exception = e; }),
                            Arbiter.Receive<Exception>(false, writeResult, e => { exception = e; })
                        );

                        total += write;
                        write = read;

                        var temp = bufferA;
                        bufferA = bufferB;
                        bufferB = temp;
                    }
                    else
                    {
                        // write remaining bytes
                        yield return (Choice)writeResult;
                        exception = (Exception)writeResult;
                    }

                    if (exception != null)
                    {
                        progress.Post(exception);
                        // handle error
                        yield break;
                    }
                }
            }
            finally
            {
                progress.Post(SuccessResult.Instance);
                source.Close();
                dest.Close();
            }
        }
    }

    public class CopyFileService : CcrServiceBase
    {
        Port<CopyFile> _operationsPort = new Port<CopyFile>();

        public CopyFileService(DispatcherQueue taskQueue)
            : base(taskQueue)
        {
            Activate(Arbiter.Receive(true, _operationsPort, HandleCopyFile));
        }

        private void HandleCopyFile(CopyFile copy)
        {
            var source = new FileStream(copy.Source, FileMode.Open, FileAccess.Read, FileShare.Read, CopyStreamHelper.BlockSize, FileOptions.Asynchronous);
            var dest = new FileStream(copy.Destination, FileMode.Create, FileAccess.Write, FileShare.None, CopyStreamHelper.BlockSize, FileOptions.Asynchronous);

            SpawnIterator(new IteratorHandler(() => CopyStreamHelper.CopyStream(source, dest, copy.ResultPort)));
        }

        public PortSet<double, SuccessResult, Exception> CopyFile(string from, string to)
        {
            return CopyFile(from, to, null);
        }

        public PortSet<double, SuccessResult, Exception> CopyFile(string from, string to, PortSet<double, SuccessResult, Exception> resultPort)
        {
            var operation = new CopyFile
            {
                Source = from,
                Destination = to,
                ResultPort = resultPort ?? new PortSet<double, SuccessResult, Exception>()
            };
            _operationsPort.Post(operation);
            return operation.ResultPort;
        }
    }

    class CopyFile
    {
        public string Source;
        public string Destination;
        public PortSet<double, SuccessResult, Exception> ResultPort;
    }

    #region advanced sample
    public class CopyFileServiceWithTokens : CcrServiceBase
    {
        Port<CopyFile> _operationsPort = new Port<CopyFile>();

        Port<EmptyValue> _tokens = new Port<EmptyValue>();

        public CopyFileServiceWithTokens(DispatcherQueue taskQueue, int tokens)
            : base(taskQueue)
        {
            Activate(Arbiter.JoinedReceiveWithIterator<CopyFile, EmptyValue>(true, _operationsPort, _tokens, HandleCopyFile));

            for (int i = 0; i < tokens; i++)
            {
                _tokens.Post(EmptyValue.SharedInstance);
            }
        }

        private IEnumerator<ITask> HandleCopyFile(CopyFile copy, EmptyValue token)
        {
            try
            {
                var source = new FileStream(copy.Source, FileMode.Open, FileAccess.Read, FileShare.Read, CopyStreamHelper.BlockSize, FileOptions.Asynchronous);
                var dest = new FileStream(copy.Destination, FileMode.Create, FileAccess.Write, FileShare.None, CopyStreamHelper.BlockSize, FileOptions.Asynchronous);

                yield return new IterativeTask(new IteratorHandler(() => CopyStreamHelper.CopyStream2(source, dest, copy.ResultPort)));
            }
            finally
            {
                _tokens.Post(token);
            }
        }

        public PortSet<double, SuccessResult, Exception> CopyFile(string from, string to)
        {
            return CopyFile(from, to, null);
        }

        public PortSet<double, SuccessResult, Exception> CopyFile(string from, string to, PortSet<double, SuccessResult, Exception> resultPort)
        {
            var operation = new CopyFile
            {
                Source = from,
                Destination = to,
                ResultPort = resultPort ?? new PortSet<double, SuccessResult, Exception>()
            };
            _operationsPort.Post(operation);
            return operation.ResultPort;
        }
    }
    #endregion
}
