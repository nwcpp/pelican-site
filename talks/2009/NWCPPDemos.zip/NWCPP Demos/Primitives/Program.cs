﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Ccr.Core;

namespace Coordination
{
    class Program
    {
        static DispatcherQueue queue;
        static Component component;

        static void Main(string[] args)
        {
            var dispatcher = new Dispatcher();

            queue = new DispatcherQueue("myqueue", dispatcher);
            component = new Component(queue);

            SimpleChoice();
            //ChoiceWithMultipleReceivers();
            //JoinedReceive();
            //ScatterGather();

            Console.ReadLine();
        }

        #region arbiter samples
        private static void ScatterGather()
        {
            var n = 1000;

            Port<string>[] resultPorts = new Port<string>[n];

            for (int i = 0; i < n; i++)
            {
                resultPorts[i] = component.PerformOperation();
            }

            Arbiter.Activate(
                queue,
                Arbiter.MultiplePortReceive(
                    false,
                    resultPorts,
                    results =>
                    {
                        Console.WriteLine("received {0} results", results.Length);
                    }
                )
            );
        }

        private static void JoinedReceive()
        {
            Arbiter.Activate(
                queue,
                Arbiter.JoinedReceive<string, string>(
                    false,
                    component.PerformOperation(),
                    component.PerformOperation(),
                    (result1, result2) =>
                    {
                        Console.WriteLine("joined {0} and {1}", result1, result2);
                    }
                )
            );
        }

        private static void SimpleChoice()
        {
            Arbiter.Activate(
                queue,
                Arbiter.Choice(
                    component.PerformOperation(OperationBehavior.NoResult),
                    result => Console.WriteLine("result: " + result),
                    exception => Console.WriteLine("exception")
                )
            );
        }

        private static void ChoiceWithMultipleReceivers()
        {
            var timer = new Port<DateTime>();
            queue.EnqueueTimer(TimeSpan.FromSeconds(20), timer);

            var resultport = component.PerformOperation(OperationBehavior.NoResult);

            Arbiter.Activate(
                queue,
                Arbiter.Choice(
                    Arbiter.Receive<string>(false, resultport,
                        result => Console.WriteLine("result: " + result)
                    ),
                    Arbiter.Receive<Exception>(false, resultport,
                        exception => Console.WriteLine("exception")
                    ),
                    Arbiter.Receive(false, timer,
                        timeout => Console.WriteLine("timeout occured at " + timeout)
                    )
                )
            );
        }
        #endregion
    }

    public class Component : CcrServiceBase
    {
        #region component internals
        Port<Operation> _operationsPort = new Port<Operation>();

        public Component(DispatcherQueue taskQueue)
            : base(taskQueue)
        {
            Activate(
                Arbiter.Receive(true, _operationsPort, HandleOperation, o => o.Behaviour == OperationBehavior.Succeed),
                Arbiter.Receive(true, _operationsPort, HandleOperationWithException, o => o.Behaviour == OperationBehavior.Fail),
                Arbiter.Receive(true, _operationsPort, DontHandleOperation, o => o.Behaviour == OperationBehavior.Fail),
                Arbiter.Receive(true, _operationsPort, SendMultipleResponses, o => o.Behaviour == OperationBehavior.MultipleResults)
            );
        }

        void HandleOperation(Operation operation)
        {
            operation.ResultPort.Post("Hello, World!");
        }

        void HandleOperationWithException(Operation operation)
        {
            operation.ResultPort.Post(new Exception());
        }

        void DontHandleOperation(Operation operation)
        { }

        void SendMultipleResponses(Operation operation)
        {
            operation.ResultPort.Post("Hello, World!");
            operation.ResultPort.Post("Hello again!");
            operation.ResultPort.Post(new Exception());
        }
        #endregion

        public PortSet<string, Exception> PerformOperation(OperationBehavior behavior)
        {
            var operation = new Operation { Behaviour = behavior };
            _operationsPort.Post(operation);

            return operation.ResultPort;
        }

        public PortSet<string, Exception> PerformOperation()
        {
            return PerformOperation(OperationBehavior.Succeed);
        }
    }

    public enum OperationBehavior
    {
        Succeed, Fail, NoResult, MultipleResults
    }

    #region operation
    public class Operation
    {
        /// <summary>
        /// The result of the operation will be posted on this port.
        /// </summary>
        public PortSet<string, Exception> ResultPort = new PortSet<string, Exception>();

        /// <summary>
        /// Value that indicates how the operation should be handled.
        /// </summary>
        public OperationBehavior Behaviour;
    }
    #endregion
}
