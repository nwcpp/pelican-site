﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Ccr.Core;

namespace Causalities
{
    class Program
    {
        static DispatcherQueue queue;
        static void Main(string[] args)
        {
            var dispatcher = new Dispatcher();
            queue = new DispatcherQueue("myqueue", dispatcher);

            var port = new Port<int>();

            var exceptions = new Port<Exception>();
            var causility = new Causality("catcher", exceptions);
            Dispatcher.AddCausality(causility);

            Arbiter.Activate(queue, Arbiter.Receive(false, port, FailWithException3));

            Arbiter.Activate(queue, Arbiter.Receive(true, exceptions, 
                e => Console.WriteLine("exception caught: " + e.Message))
            );

            port.Post(42);
        }

        static void FailWithException3(int value)
        {
            var exceptions = new Port<Exception>();
            var causility = new Causality("catcher2", exceptions);
            Dispatcher.AddCausality(causility);

            var port = new Port<int>();
            port.Post(value);

            Arbiter.Activate(queue,
                Arbiter.Receive(false, port, FailWithException)
            );

            Arbiter.Activate(queue, Arbiter.Receive(true, exceptions,
                e => Console.WriteLine("exception caught inside handler: " + e.Message))
            );
        }

        static void FailWithException2(int value)
        {
            var port = new Port<int>();
            port.Post(value);

            Arbiter.Activate(queue,
                Arbiter.Receive(false, port, FailWithException)
            );
        }

        static void FailWithException(int value)
        {
            throw new Exception("Catch me if you can!");
        }
    }
}
