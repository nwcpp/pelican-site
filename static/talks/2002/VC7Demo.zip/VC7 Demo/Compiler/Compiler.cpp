// Compiler.cpp : Defines the entry point for the application.
//

#include "stdafx.h"


//=============================================================================
// Demonstrate some new predefined macros
class MyClass
{
public:
	static void NewMacros()
	{
		cout << "__FUNCDNAME__  " << __FUNCDNAME__ << endl;
		cout << "__FUNCSIG__    " << __FUNCSIG__   << endl;
		cout << "__FUNCTION__   " << __FUNCTION__  << endl;
	}
};

//=============================================================================
// Preprocessor: new pragma "deprecated"
#pragma deprecated(strlen)

void Deprecated() {
	cout << (unsigned)strlen("hi") << endl;
}


//=============================================================================
// Interface: New keyword "__interface", and "explicit overrides"
__interface IPrint1 {
	void Print();
};

class IPrint2 {
public:
	virtual void Print() = NULL;
};

class Printer : public IPrint1, public IPrint2
{
public:
	void IPrint1::Print() { cout << "Printing1...\n"; }
	void IPrint2::Print() { cout << "Printing2...\n"; }
};

void Interface()
{
	IPrint1* p1 = new Printer;
	IPrint2* p2 = dynamic_cast<IPrint2*>(p1);
	p1->Print();
	p2->Print();
}


//=============================================================================
// VC7 follows finally the official scope rules
void For()
{
	for( int i=0; i<7; i++) {;}
	for( int i=0; i<7; i++) {;}
	int i=0;
}


//=============================================================================
// New keyword: __if_exists (and also __if_not_exists)
template<class T> void PrintOrDie( T& t) 
{
	__if_exists( T::Print) { t.Print(); }
	__if_exists( T::Die)   { t.Die(); }
}

class CPrint {
public:
	void Print() { cout << "Print" << endl; }
};

class CDie {
public:
	void Die() { cout << "Die" << endl; }
};

void IfExists()
{
	PrintOrDie( CPrint());
	PrintOrDie( CDie());
}


//=============================================================================
// New keyword: __super (stolen from Java...)
class Dad {
public:
	Dad() {};
	virtual void Hi() { cout << "Hi"; }
};

class Kid : public Dad {
public:
	Kid() {};
	virtual void Hi() { 
		__super::Hi();
		Dad::Hi();
		cout << "Ho" << endl; 
	}
};

void Super() 
{
	Kid k;
	k.Hi();
}


//=============================================================================
// "Function try-catch": catches exceptions from the constructors init-list

class C
{
private:	int m_i;
public:		C( const int i);
public:		void init( const int i);
};


C::C( const int i)
try 
	: m_i( init(i))
{
// The regulat constructor code:
	if( i == 2) 
		throw "throwing from inside the c'tor";
	cout << "C was successfully constructed" << endl;
}
catch( const char* p)
{
// The exception handler code
	cout << "caught an constructor exception: " << p << endl;
}

void C::init( const int i)
{
	if( i == 1) 
		throw "throwing from a function"; 
	m_i = i; 
}

void FunctionTryCatch()
{
	C c0(0);
	C c1(1);
	C c2(2);
}


//=============================================================================
// SSE: Quite exotic, but the memory streaming commands are extremely useful
#include <xmmintrin.h>
void SSE()
{
	const int MAX = 1*1024*1024;
#ifdef _DEBUG
	const int CNT = 10;
#else
	const int CNT = 100;
#endif
	int* pi = new int[MAX];
	int max;
	DWORD t1,t2,t3;

//--------------------------------------------------------------------------
// Fill buffer. Look then later for the max value.
	srand( ::GetTickCount());
	for( int i = 0; i < MAX; i++) { pi[i] = (short)rand(); }

//--------------------------------------------------------------------------
// Simple: Go through all values, look for the max.
	t1 = ::GetTickCount();
	max = 0;
	for( int cnt = 0; cnt < CNT; cnt++) 
	{
		for( int i = 0; i < MAX; i++)
		{
			if( pi[i] > max) { max = pi[i]; }
		}
	}
	_mm_empty();
	t1 = ::GetTickCount() - t1;
	cout << "default: " << t1 << "ms / max=" << max << endl;

//--------------------------------------------------------------------------
// Two steps are required:
//	- Call prefetch
//	- Process some other data (not the prefetched data!)
	t2 = ::GetTickCount();
	max = 0;
	for( int cnt=0; cnt < CNT; cnt++)
	{
		for( int i = 0; i < MAX; i += 4)
		{
			_mm_prefetch( (char*)(&pi[i+4]), _MM_HINT_T0 );
			if( pi[i+0] > max) { max = pi[i+0]; }
			if( pi[i+1] > max) { max = pi[i+1]; }
			if( pi[i+2] > max) { max = pi[i+2]; }
			if( pi[i+3] > max) { max = pi[i+3]; }
		}
	}
	_mm_empty();
	t2 = ::GetTickCount() - t2;
	cout << "prefetch (16 byte ahead): " << t2 << "ms / max=" << max << endl;
	cout << "speed gain with prefetch: " << 100 - (t2*100)/t1 << "%" << endl; //12%

//--------------------------------------------------------------------------
// Two steps are required:
//	- Call prefetch
//	- Process some other data (not the prefetched data!)
	t3 = ::GetTickCount();
	max = 0;
	for( int cnt=0; cnt < CNT; cnt++)
	{
		for( int i = 0; i < MAX; i += 8)
		{
			_mm_prefetch( (char*)(&pi[i+8]), _MM_HINT_T0 );
			if( pi[i+0] > max) { max = pi[i+0]; }
			if( pi[i+1] > max) { max = pi[i+1]; }
			if( pi[i+2] > max) { max = pi[i+2]; }
			if( pi[i+3] > max) { max = pi[i+3]; }
			if( pi[i+4] > max) { max = pi[i+4]; }
			if( pi[i+5] > max) { max = pi[i+5]; }
			if( pi[i+6] > max) { max = pi[i+6]; }
			if( pi[i+7] > max) { max = pi[i+7]; }
		}
	}
	_mm_empty();
	t3 = ::GetTickCount() - t3;
	cout << "prefetch (32 byte ahead): " << t3 << "ms / max=" << max << endl;
	cout << "speed gain with prefetch: " << 100 - (t3*100)/t1 << "%" << endl; //32%

//--------------------------------------------------------------------------
	delete []pi;
}


//=============================================================================
void main()
{
	MyClass::NewMacros();
	Deprecated();
	Interface();
	IfExists();
	Super();
	FunctionTryCatch();
	SSE();
}