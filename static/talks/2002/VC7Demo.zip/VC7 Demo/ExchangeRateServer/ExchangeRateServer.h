// ExchangeRateServer.h : Defines the ATL Server request handler class
//
#pragma once

namespace ExchangeRateServerService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IExchangeRateServerService - web service interface declaration
//
[
	uuid("F40335E5-8769-413D-B893-B4333BC9CDD3"), 
	object
]
__interface IExchangeRateServerService
{
	[helpstring("method GetExchangeRage")] HRESULT GetExchangeRate([in] BSTR from, [in] BSTR to, [out,retval] DOUBLE* rate);
};


// ExchangeRateServerService - web service implementation
//
[
	request_handler(name="Default", sdl="GenExchangeRateServerWSDL"),
	soap_handler(
		name="ExchangeRateServerService", 
		namespace="urn:ExchangeRateServerService",
		protocol="soap"
	)
]
class CExchangeRateServerService :
	public IExchangeRateServerService
{
public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT GetExchangeRate(BSTR from, BSTR to, DOUBLE* rate)
	{
		//::MessageBox( NULL, _T("GetExchangeRate"), _T("GetExchangeRate"), 0);


		//FILE* fp = _tfopen( _T("ExchangeRateServerLog.txt"), _T("at"));
		//if( fp) {
		//	const time_t currTime = time(NULL);
		//	_ftprintf( fp, _T("%s"), _tctime( &currTime));
		//	_ftprintf( fp, _T("  from: %s\n"), from);
		//	_ftprintf( fp, _T("    to: %s\n"), to);
		//	fclose(fp);
		//}

		static const double USD2DEM = 2.2113;

		if( lstrcmp( from, L"USD") == 0)
		{
			if( lstrcmp( to, L"USD") == 0) { *rate = 1;       return S_OK; }
			if( lstrcmp( to, L"DEM") == 0) { *rate = USD2DEM; return S_OK; }
			return S_FALSE;
		}
		if( lstrcmp( from, L"DEM") == 0)
		{
			if( lstrcmp( to, L"DEM") == 0) { *rate = 1;         return S_OK; }
			if( lstrcmp( to, L"USD") == 0) { *rate = 1/USD2DEM; return S_OK; }
			return S_FALSE;
		}
		return S_FALSE;
	}
}; // class CExchangeRateServerService

} // namespace ExchangeRateServerService
