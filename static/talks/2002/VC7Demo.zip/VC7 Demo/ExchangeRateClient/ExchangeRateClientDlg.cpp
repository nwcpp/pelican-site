// ExchangeRateClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ExchangeRateClient.h"
#include "ExchangeRateClientDlg.h"
#include "SoapDebugClient.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CExchangeRateClientDlg dialog



CExchangeRateClientDlg::CExchangeRateClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CExchangeRateClientDlg::IDD, pParent)
	, m_dRate(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CExchangeRateClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_FROM, m_cmbFrom);
	DDX_Control(pDX, IDC_TO, m_cmbTo);
	DDX_Text(pDX, IDC_RATE, m_dRate);
}

BEGIN_MESSAGE_MAP(CExchangeRateClientDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_GETEXCHANGERATE, OnBnClickedGetexchangerate)
END_MESSAGE_MAP()


// CExchangeRateClientDlg message handlers

BOOL CExchangeRateClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	//ShowWindow(SW_MINIMIZE);

	// TODO: Add extra initialization here
	m_cmbFrom.AddString(_T("USD"));	m_cmbTo.AddString(_T("USD"));
	m_cmbFrom.AddString(_T("DEM"));	m_cmbTo.AddString(_T("DEM"));

	m_cmbFrom.SetCurSel(0);		m_cmbTo.SetCurSel(1);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CExchangeRateClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CExchangeRateClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CExchangeRateClientDlg::OnBnClickedGetexchangerate()
{
	TCHAR tszFrom[16], tszTo[16];
	m_cmbFrom.GetLBText( m_cmbFrom.GetCurSel(), tszFrom);
	m_cmbTo.GetLBText(   m_cmbTo.GetCurSel(), tszTo);

	ExchangeRateServerService::CExchangeRateServerService service;

	//ExchangeRateServerService::CExchangeRateServerServiceT<CSoapDebugClient> service;
	//service.SetSoapAppDllPath("..\\ExchangeRateServer\\Debug\\ExchangeRateServer.dll");
	//service.SetOutputFile(_T("CSoapDebugClient.txt"));

	HRESULT hr = service.GetExchangeRate( tszFrom, tszTo, &m_dRate);

	if( SUCCEEDED(hr))
	{
		UpdateData(FALSE);
	}
	else
	{
		TCHAR tsz[1024];
		::FormatMessage( FORMAT_MESSAGE_FROM_SYSTEM, NULL, hr, 0, tsz, 1024, NULL);
		MessageBox( tsz, _T("WebService call failed:"));
	}
}
