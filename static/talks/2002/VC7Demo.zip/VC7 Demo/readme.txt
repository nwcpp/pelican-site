Content:
--------
This package contains some source code and a HTML dump of the presentation given at the february NWCPP meeting.

Source code:
------------
\Compiler	Some samples regarding compiler features and new C++ enhancements.
\RuntimeCheck	Some samples explaining new debugging and runtime error detection features.
\BasicMfc	Benchmark code for the map/hash_map/CMap and the string/CString/CFixedString comparison
\Exchange*	A tiny WebService based on the new ATL Server classes

Requirements:
-------------
To build the code, you need the .NET Studio Beta2 (or higher).
To run the ExchangeServer demo, you also need IIS on your machine.

Copyright:
----------
(C) 2002, Christian Harlass, Saxonia Systems.
christian.harlass@saxsys.de

Legal stuff:
------------
This material is for personal education purposes only.
No permission for any commercial usage granted.