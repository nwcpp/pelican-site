// BasicMfc.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "BasicMfc.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define ECNT(arr) (sizeof(arr)/sizeof(*arr))

// The one and only application object
CWinApp theApp;
using namespace std;


//=============================================================================
// Show the class size
void String_ClassSize()
{
	cout << "std::string: " << sizeof(std::string) << endl;
	cout << "CString: " << sizeof(CString) << endl;
	cout << "ATL::CFixedStringT<CString,15>: " << sizeof(ATL::CFixedStringT<CString,10>) << endl;
	cout << "ATL::CFixedStringT<CString,20>: " << sizeof(ATL::CFixedStringT<CString,20>) << endl;
	cout << endl;
}

//=============================================================================
// Show the class size
void String_HeapUsage()
{
	_CrtMemState st1, st2, diff;

#define TEST(type,txt)	\
		{	cout << "\n--- " << #type << " ---" << endl;	\
			_CrtMemCheckpoint( &st1);					\
			type t = txt;								\
			_CrtMemCheckpoint( &st2);					\
			_CrtMemDifference( &diff, &st1, &st2);		\
			_CrtMemDumpStatistics( &diff);	} 

	TEST( std::string, "123456789012345");	// 15 chars => heap=0
	TEST( std::string, "1234567890123456");	// 16 chars => heap=32

	TEST( CString, "12");					//  2 chars => heap=19
	TEST( CString, "12345678901234567890");	// 20 chars => heap=37

	typedef ATL::CFixedStringT<CString,10> CFixedString10;	// for the macro...
	TEST( CFixedString10, "1234567890");	// 10 chars => heap=0
	TEST( CFixedString10, "12345678901");	// 11 chars => heap=37

#undef TEST
}

//=============================================================================
// Demonstrate the speed of tiny/large strings
void String_AllocationSpeed( char* text)
{
#ifdef _DEBUG
	const int ARRAY_SIZE = 10000;
#else
	const int ARRAY_SIZE = 200000;
#endif

#define TEST(type)	\
	{	type arr[ARRAY_SIZE];									\
		DWORD t1 = ::GetTickCount();							\
		for( int i = 0; i < ECNT(arr); i++) { arr[i] = text; }	\
		DWORD t2 = ::GetTickCount();							\
		cout << "\nAlloc " << #type << " text=" << text << " time=" << t2-t1 << endl;	\
	}

	typedef ATL::CFixedStringT<CString,10> CFixedString10;	// for the macro...
	TEST( std::string );
	TEST( CString );
	TEST( CFixedString10 );

#undef TEST
}

//=============================================================================
// Show how to use MFC strings with STL algorithms
// Why not using std::string? It is slower.
void String_StlAlgorithm()
{
	ATL::CFixedStringT<CString,30> s = "No std::string, please";
	cout << (LPCTSTR)s << endl;

	char* itr1 = s.GetBuffer();
	char* itr2 = itr1 + s.GetLength();
	std::sort( itr1, itr2);

	cout << (LPCTSTR)s << endl;
}


//=============================================================================
// A good string class should have the char* as first data member
void String_FoolProof()
{
	//std::string s1 = "short";
	//printf( "%s\n", s1);		// no...

	//std::string s1 = "very very very long";
	//printf( "%s\n", s1);		// no...

	CString s2 = "any size";
	printf( "%s\n", s2);

	//ATL::CFixedStringT<CString,10> s3 = "short";
	//printf( "%s\n", s3);

	//ATL::CFixedStringT<CString,10> s4 = "very very very long";
	//printf( "%s\n", s4);
}


//=============================================================================
void Hash()
{
	DWORD t1,t2,t3;

#ifdef _DEBUG
	const int CNT = 20000;
#else
	const int CNT = 400000;
#endif

	{
	_CrtMemState st1, st2, diff;
	_CrtMemCheckpoint( &st1);			
		hash_map<int,int> m;
		hash_map<int,int>::iterator itr;	// prevents optimization
		t1 = ::GetTickCount();
		for( int i = 0; i < CNT; i++) { m[i] = i; }
		t2 = ::GetTickCount();
		for( int i = 0; i < CNT; i++) { itr=m.find(i); }
		t3 = ::GetTickCount();
		cout << "\nhash_map: insert=" << t2-t1 << " lookup=" << t3-t2 << " " << (*itr).first << endl;
	_CrtMemCheckpoint( &st2);			
	_CrtMemDifference( &diff, &st1, &st2);
	_CrtMemDumpStatistics( &diff);
	}
	{
	_CrtMemState st1, st2, diff;
	_CrtMemCheckpoint( &st1);			
		map<int,int> m;
		map<int,int>::iterator itr;			// prevents optimization
		t1 = ::GetTickCount();
		for( int i = 0; i < CNT; i++) { m[i] = i; }
		t2 = ::GetTickCount();
		for( int i = 0; i < CNT; i++) { itr=m.find(i); }
		t3 = ::GetTickCount();
		cout << "\nmap:      insert=" << t2-t1 << " lookup=" << t3-t2 << " " << (*itr).first << endl;
	_CrtMemCheckpoint( &st2);			
	_CrtMemDifference( &diff, &st1, &st2);
	_CrtMemDumpStatistics( &diff);
	}
	{
	_CrtMemState st1, st2, diff;
	_CrtMemCheckpoint( &st1);			
		CMap<int,int,int,int> m;
		int v; 							// prevents optimization
		m.InitHashTable(CNT*6/5);		// Absolutely required, otherwise snail-slow!!!
		t1 = ::GetTickCount();
		for( int i = 0; i < CNT; i++) { m[i] = i; }
		t2 = ::GetTickCount();
		for( int i = 0; i < CNT; i++) { m.Lookup(i,v); }
		t3 = ::GetTickCount();
		cout << "\nCMap:     insert=" << t2-t1 << " lookup=" << t3-t2 << " " << v << endl;
	_CrtMemCheckpoint( &st2);			
	_CrtMemDifference( &diff, &st1, &st2);
	_CrtMemDumpStatistics( &diff);
	}
}


//=============================================================================
int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
		_CrtSetReportMode( _CRT_WARN, _CRTDBG_MODE_FILE);
		_CrtSetReportFile( _CRT_WARN, _CRTDBG_FILE_STDOUT);

		String_ClassSize();
		String_HeapUsage();
		String_AllocationSpeed( "tiny");
		String_AllocationSpeed( "larger than 15 byte");
		String_StlAlgorithm();
		String_FoolProof();
		Hash();
	}

	return nRetCode;
}
