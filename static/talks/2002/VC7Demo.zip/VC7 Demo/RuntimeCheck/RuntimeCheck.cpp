// RuntimeCheck.cpp : Defines the entry point for the application.
// See also MSDN, compiler options /GS and /RTC

#include "stdafx.h"


//=============================================================================
// Two dummy methods, explicitely declared as "__cdecl"
int __cdecl func1()
{
	return 1234;
}

int __cdecl func2()
{
	__asm add ebp,4;	// Modify the stack pointer � la John Wayne
	return 5678;
}

//=============================================================================
// Calling a __cdecl-function as __stdcall should raise a RTC exception:
void DoStackPointerCorruption()
{
	int (__stdcall* pfunc1)() = (int(__stdcall*)())func1;
	cout << (pfunc1)() << endl;	// No reaction here. Why?
	cout << func2 << endl;		// Ahh!
}


//=============================================================================
// Check stack(!) variables
void DoStackMemoryCorruption()
{
// Show a stack memory corruption
	{
		char sz[2];
		strcpy( sz, "hi");			// OK, 1 byte to much
	}
	cout << "This is still executed!" << endl;

// Show a heap memory corruption (exists already in VC6)
// Remains undetected until I call "delete []psz" !
	//char* psz = new char[2];
	//strcpy( psz, "hi");	
}


//=============================================================================
// Detects data loss on down castings
void DoCastError()
{
	int i = 1111;
	char c1 = i;					// compiler warning on WarningLevel 4, RTC exception
	char c2 = (char)i;				// compiles ok at WarningLevel 4, RTC exception
	char c3 = static_cast<char>(i);	// compiles ok at WarningLevel 4, RTC exception
	char c4 = (char)(i & 0xFF);		// No RTC exception
}


//=============================================================================
// Detects uninitialized variables
void DoUnitializedVariables()
{
	int a;
//	a = 0xCCCCCCCC;	// The value VC uses to detect these violations
	int b = a;
}


//=============================================================================
// Simply print the currently detected RTC's
void DescribeErrors()
{
	for( int i = 0; i < _RTC_NumErrors(); i++)
		cout << i << " " << _RTC_GetErrDesc( (_RTC_ErrorNumber)i) << endl;
}


//=============================================================================
void __cdecl report_failure(int code, void * unused)
{
   if(code == _SECERR_BUFFER_OVERRUN)
      printf("Buffer overrun detected! Program will end.\n");
   exit(1);
}

void DoBufferSecurity()
{
	_set_security_error_handler( report_failure);
	char dest[10];
	strcpy( dest, "Much to much :-) \n");
	cout << dest;
}


//=============================================================================
void main()
{
	for(;;) {
		cout << endl;
		cout << "d Describe errors" << endl; 
		cout << "c Cast error" << endl;
		cout << "u Uninitialized variables" << endl;
		cout << "p stack Pointer corruption" << endl;
		cout << "m stack Memory corruption" << endl;
		cout << "b Buffer security" << endl;
		cout << "q Quit" << endl;
		cout << "> ";

		char choice[22];
		cin >> choice;

		switch( choice[0])
		{
			case 'd':	DescribeErrors();			break;
			case 'c':	DoCastError();				break;
			case 'u':	DoUnitializedVariables();	break;
			case 'p':	DoStackPointerCorruption();	break;
			case 'm':	DoStackMemoryCorruption();	break;
			case 'b':	DoBufferSecurity();			break;
			case 'q':	return;
			default:	cout << "???" << endl;		break;
		}
	}
}

