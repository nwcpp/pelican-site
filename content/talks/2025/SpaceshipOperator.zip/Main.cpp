/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

import Examples;

#include <vector>
#include <string>
#include <iostream>

//void default_spaceship_vector();

int main()
{
	auto_deduced_examples();
	point_examples();
	frac_default_spaceship_examples();
	frac_implemented_spaceship_examples();
	limit_order_examples();
}


